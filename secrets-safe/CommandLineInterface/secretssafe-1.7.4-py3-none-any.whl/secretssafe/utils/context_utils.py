from secretssafe.config import DEFAULT_API_VERSION, ALL_ENV_VAR_NAMES, WINDOWS, SECRETSSAFE_HOST, SECRETSSAFE_PORT, SECRETSSAFE_VERIFY_CA
from secretssafe.config import SecretsSafeConfiguration
import os
import json
from pathlib import Path

DEFAULT_CONTEXT_NAME = 'default'

def get_dict_from_iter(key, value, iterable):
    return next((item for item in iterable if item.get(key) == value), None)

def get_context_json():
    contexts_json = {}
    contexts_file_path = get_contexts_file_path()
    if os.path.isfile(str(contexts_file_path)):
        contexts_json = load_json(contexts_file_path)
    return contexts_json


def load_contexts(config, environment_overrides=False):
    # load the context from file
    contexts = []
    contexts_json = get_context_json()
    contexts = contexts_json.get('contexts') or {}
    config.contexts = contexts
    # set the current context if we have one
    if 'current_context' in contexts_json and contexts_json['current_context'] is not None:
        context = get_dict_from_iter('name', contexts_json.get('current_context'), contexts)
        config.current_context = context
    
    if not config.current_context:
        # no current context set so use the default
        default_context = get_dict_from_iter('name', DEFAULT_CONTEXT_NAME, contexts)
        if default_context:
            config.current_context = default_context
        else:
            # default context does not yet exist, create it
            default_context = get_default_context()
            config.current_context = default_context
            persist_context(config, default_context)

    if environment_overrides:
        env_overrides = get_context_environment_overrides()
        config.current_context = {**config.current_context, **env_overrides}
    return contexts


def get_default_context():
    return {'name': DEFAULT_CONTEXT_NAME, 'api_version': DEFAULT_API_VERSION}

def get_context_environment_overrides():
    # check all properties that can be configured via envinronment variable
    env_values_map = {}
    for env_name in ALL_ENV_VAR_NAMES:
        if os.environ.get(env_name):
            env_values_map[env_name] = os.environ.get(env_name)
    return env_values_map

def initialize_context(log, config):
    try:
        load_contexts(config, True)
    except:
        log.error('error initializing context')
        return False
    
    return True

def get_current_context(config):
    load_contexts(config, True)
    return config.current_context

def delete_context(config, context_name):

    for i, context in enumerate(config.contexts):
        if context.get('name') == context_name:
            del config.contexts[i]
            break
    if config.integrated:
        return
    current_context_name = config.current_context.get('name')
    contexts_json = get_context_json()

    if 'contexts' in contexts_json:
        for i, context in enumerate(contexts_json['contexts']):
            # User cannot delete the last remaining context and will get a warning
            if len(contexts_json['contexts']) == 1:
                print('Cannot delete last remaining context')
                break
            if context.get('name') == context_name:
                del contexts_json['contexts'][i]
                break
        write_to_configuration(contexts_json['contexts'], current_context_name)


def persist_context(config, context):
    # don't persist anything in integrated mode
    if config.integrated:
        return

    contexts = [context for context in config.contexts]
    for i, the_context in enumerate(contexts):
        if the_context.get('name') == context.get('name'):
            contexts[i] = context
            break
    else:
        contexts.append(context)

    current_context_name = config.current_context.get('name')
    write_to_configuration(contexts, current_context_name)
    config.contexts = contexts

def write_to_configuration(contexts, current_context_name):
    contexts_file_path = get_contexts_file_path()
    dump_json(
        contexts_file_path,
        {
            'current_context': current_context_name,
            'contexts': contexts
        }
    )
    if os.name == WINDOWS:
        set_windows_file_attributes(contexts_file_path)

def persist_context_patch(config, context_name, values_map, reload_context=True):
    if config.integrated:
        return

    target_context = get_context(SecretsSafeConfiguration(), context_name)
    if not target_context:
        return False
    updated_context = {**target_context, **values_map}
    persist_context(config, updated_context)
    # reload context with new changes as well as environment overrides
    if reload_context:
        load_contexts(config, True)
    # delete a specific property from a context on disk        

def persist_context_delete(config, context_name, property_name):
    if config.integrated:
        return
    target_context = get_context(SecretsSafeConfiguration(), context_name)
    if not target_context:
        return False
    if not property_name in target_context:
        return
    del target_context[property_name]
    persist_context(config, target_context)

def get_context(config, name):
    return get_dict_from_iter('name', name, load_contexts(config))

def get_contexts_file_path():
    prefix = '.' if os.name != WINDOWS else ''
    contexts_file_name = prefix + 'secretssafe_contexts.json'
    return Path.home() / contexts_file_name

def check_required_vars(log, var_map, var_name):
    if not var_map.get(var_name):
        log.error(var_name + ' configuration variable not found.')
        return False
    return True

def dump_json(file_path, json_data):
    try:
        os.remove(str(file_path))
    except OSError:
        pass
    with open(str(file_path), 'a+') as file:
        json.dump(json_data, file, indent=4)

# pylint: disable=no-member,import-outside-toplevel,import-error,c-extension-no-member,multiple-imports
def set_windows_file_attributes(contexts_file_path):
    import win32con, win32file
    flags = win32file.GetFileAttributesW(str(contexts_file_path))
    win32file.SetFileAttributes(str(contexts_file_path), win32con.FILE_ATTRIBUTE_HIDDEN | flags)

def load_json(file_path):
    with open(str(file_path)) as file:
        return json.load(file)


def build_context_table(config, context):
    current_context_name = config.current_context.get('name')
    return [
        '*' if current_context_name == context.get('name') else '',
        context.get('name'),
        context.get(SECRETSSAFE_HOST),
        context.get(SECRETSSAFE_PORT),
        context.get('api_version'),
        context.get(SECRETSSAFE_VERIFY_CA)
        ]
