# pylint: disable=protected-access,too-many-ancestors,no-member,unused-argument
import argparse
import textwrap
from cement.ext import ext_argparse
import sys as _sys
from gettext import gettext


class ArgparseArgumentHandlerOverride(ext_argparse.ArgparseArgumentHandler):

    def __init__(self, *args, **kwargs):
        super().__init__(
            *args,
            **{
                'formatter_class': SubcommandHelpFormatter,
                'allow_abbrev': False,
                **kwargs
                }
            )

    def error(self, message):
        """error(message: string)

        Prints a usage message incorporating the message to stderr and
        exits.

        If you override this in a subclass, it should not return -- it
        should either exit or raise an exception.
        """

        # cement has collections of parsers nested within each other. In the event of an unrecognized
        # argument the error bubbles up and show_usage() is called for the app parser instead of the
        # more specific parser for that command. We do however have enough information in the args
        # to retrieve the more specific parser and display it's print_usage() instead

        if 'unrecognized arguments:' in message:
            try:
                # namespace is for the controller
                sub_parser_namespace = args.__controller_namespace__
                # command is for the actual command called on the controller
                sub_parser_command = args.command
                controller_parser = self._get_parser_from_actions(self._actions, sub_parser_namespace)
                # we have a parser for the controller
                if controller_parser:
                    command_parser = self._get_parser_from_actions(controller_parser._actions, sub_parser_command)
                    # we have a parser for the command so use it's print_usage and exit
                    if command_parser:
                        command_parser.print_usage(_sys.stderr)
                        args = {'prog': self.prog, 'message': message}
                        self.exit(2, gettext('%(prog)s: error: %(message)s\n') % args)
            except Exception:
                # if anything goes wrong just let the error trickle down to the superclass
                pass
        # if we have gotten this far we know the error wasn't unrecognized argument or we couldn't find a more
        # specific parser
        super(ArgparseArgumentHandlerOverride, self).error(message)

    def _get_parser_from_actions(self, actions,  parser_name):
        for action in actions:
            if action.choices is not None and action.choices.get(parser_name):
                return action.choices[parser_name]


class SubcommandHelpFormatter(argparse.RawDescriptionHelpFormatter):

    def __init__(self, *args, **kwargs):
        super().__init__(
            *args,
            **{**kwargs, 'max_help_position': 35, 'width': 120}
            )

    def add_usage(self, usage, actions, groups, prefix=None):
        if prefix is None:
            prefix = 'Usage: '
        return super().add_usage(usage, actions, groups, prefix)

    def _format_action(self, action):
        parts = super()._format_action(action)
        if action.nargs == argparse.PARSER:
            parts = '\n'.join(parts.split('\n')[1:])
        return parts

    def _format_usage(self, usage, actions, groups, prefix):
        for action in actions:
            if action.help == 'show this help message and exit':
                action.help = ': Show this help message and exit.'
            if action.help == 'suppress all console output':
                action.help = ': Suppress all console output.'
            if action.nargs == argparse.PARSER:
                return super()._format_usage(
                    'ssrun [-h/--help] [-q/--quiet] [-v/--version] [sub-command]',
                    actions, groups, prefix)
        return super()._format_usage(usage, actions, groups, prefix)

    def _iter_indented_subactions(self, action):
        try:
            get_subactions = action._get_subactions
        except AttributeError:
            pass
        else:
            self._indent()
            if isinstance(action, argparse._SubParsersAction):
                for subaction in sorted(get_subactions(), key=lambda x: x.dest):
                    yield subaction
            else:
                for subaction in get_subactions():
                    yield subaction
            self._dedent()

    def _format_action_invocation(self, action):
        if not action.option_strings:
            metavar, = self._metavar_formatter(action, action.dest)(1)
            return metavar
        parts = []
        if action.nargs == 0:
            parts.extend(action.option_strings)
        else:
            for option_string in action.option_strings:
                parts.append('%s' % option_string)
        return ', '.join(parts)

    def _split_lines(self, text, width):
        text = self._whitespace_matcher.sub(' ', text).strip()
        return textwrap.wrap(text, width, subsequent_indent='  ')


def action_call(self, parser, namespace, values, option_string=None):
    if getattr(namespace, self.dest, self.default) is not self.default:
        parser.error('Argument ' + option_string + ' provided more than once.')
    setattr(namespace, self.dest, values)


def const_call(self, parser, namespace, values, option_string=None):
    if getattr(namespace, self.dest, self.default) is not self.default:
        parser.error('Argument ' + option_string + ' provided more than once.')
    setattr(namespace, self.dest, self.const)
