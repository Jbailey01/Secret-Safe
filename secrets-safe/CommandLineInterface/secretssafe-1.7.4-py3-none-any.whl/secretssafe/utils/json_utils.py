import os
import json

def pprint_json(json_data):
    print(json.dumps(json_data, indent=4))


def filter_json_fields(fields, json_array):
    filtered_fields = []
    for json_obj in json_array:
        filtered_fields.append([json_obj.get(field) for field in fields])
    return filtered_fields


def format_json_string(json_string):
    return json.dumps(json.loads(json_string), indent=4)


def is_json_string(decoded_content):
    try:
        json.loads(decoded_content)
    except json.decoder.JSONDecodeError:
        return False
    except TypeError:
        return False
    return True


def dump_json(file_path, json_data):
    try:
        os.remove(str(file_path))
    except OSError:
        pass
    with open(str(file_path), 'a+') as file:
        json.dump(json_data, file, indent=4)
