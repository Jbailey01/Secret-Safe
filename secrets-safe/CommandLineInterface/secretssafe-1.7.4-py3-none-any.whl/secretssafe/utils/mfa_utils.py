import qrcode
import pyotp
import os

TOTP_ISSUER = "DSS"


def generate_totp_secret_and_qr_code(principal_uri):
    generated_totp = pyotp.random_base32()
    totp_provisioning_uri = pyotp.totp.TOTP(generated_totp).provisioning_uri(name=principal_uri,
                                                                             issuer_name=TOTP_ISSUER)
    qr = qrcode.QRCode()
    qr.add_data(totp_provisioning_uri)
    qr.make(fit=True)
    return (generated_totp, qr)
