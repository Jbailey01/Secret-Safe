import os
from getpass import getpass
from cement.utils.shell import Prompt
import base64
from secretssafe.config import (INVALID_SUFFIX, SECRETSSAFE_API_RESPONSE,
                                PRINCIPAL_NAME_REGEX, MIN_NAME_LENGTH,
                                MAX_NAME_LENGTH)
from secretssafe.utils.json_utils import pprint_json, is_json_string

def is_null_or_whitespace(string):
    if not string:
        return True
    if is_whitespace(string):
        return True
    return False


def is_whitespace(string):
    return not trim(string)


def is_digit(value):
    if not value:
        return False
    return value.isdigit()


def log_invalid_error_message(log, entity, details=None):
    extra_data = '. ' + details if details else ''
    log.error(entity + INVALID_SUFFIX + extra_data)


def validate_resource_uri(resource_prefix, uri):
    is_valid, formatted_uri = validate_string(uri)
    if is_valid:
        formatted_uri = formatted_uri.lstrip('/')
        is_valid = formatted_uri.startswith(resource_prefix)
    return is_valid, formatted_uri


def validate_string(string):
    if not is_null_or_whitespace(trim(string)):
        return True, trim(string)
    return False, None


def validate_base64_string(string):
    trimmed_string = trim(string)
    # only validate if string has a value
    if is_null_or_whitespace(trimmed_string):
        return True, trimmed_string
    try:
        base64.b64decode(trimmed_string)
        # this can be decoded, return the encoded value
        return True, trimmed_string
    except base64.binascii.Error:
        return False, trimmed_string


def validate_digit(value):
    if is_digit(value):
        return True, value
    return False, None


def validate_ssl_config(string):
    if is_null_or_whitespace(string):
        # Default to True
        return True, 'True'
    if trim(string).upper() == 'FALSE':
        # For consistency lets normalize the result
        return True, 'False'
    if trim(string).upper() == 'TRUE':
        # For consistency lets normalize the result
        return True, 'True'
    # Assume its the path to the CA certificate
    return True, string


def prompt(prompt_query, default=None):
    return Prompt(prompt_query, default=default).input


# Define prompt_password will attempt to prompt for a password.  If successful,
# the first result will be 'true' and the second result will contain the password.
# Otherwise, the first result will be 'false' and the second result will either be
# null or contains a specific error message
def prompt_password(confirm, prompt_msg=None):
    is_valid, password = try_get_pass(prompt_msg + ': ' if prompt_msg else 'Password: ')
    if not is_valid:
        return is_valid, prompt_msg + ' is invalid.' if prompt_msg else 'Password is invalid.'
    if confirm:
        is_valid, confirmation = try_get_pass('Confirm password: ')
        if not is_valid:
            return is_valid, 'Confirm password is invalid.'
        is_valid = password == confirmation
        if not is_valid:
            return is_valid, 'Passwords did not match.'
    return is_valid, password


def prompt_confirm(msg):
    prompt_response = Prompt(msg + ' [Y/n]?', default='Y').input
    confirmed = {'y': True, 'n': False}.get(prompt_response.lower())
    if confirmed is None:
        prompt_confirm(msg)
    return confirmed


# Define get_from_pargs_or_prompt will first attempt to extract the specified
# command line arguement and validate it using the specified validation function.
# If it does not exist, or fails validation, it will then prompt the user
# (up to 2 times) to specify a value and again attempt to validate it using the
# specifed validation function.
def get_from_pargs_or_prompt(input_validator, pargs, attr, prompt_query, default=None):
    has_value, value = try_has_value_from_pargs(pargs, attr)
    if not has_value:
        value = prompt(prompt_query, default)
    is_valid, value = input_validator(value)
    return is_valid, value


def try_get_pass(prompt_msg):
    password = getpass(prompt_msg)
    if is_null_or_whitespace(password):
        return False, None
    return True, password


def try_get_value_from_pargs_or_default(pargs, attr, default):
    is_valid, value = try_has_value_from_pargs(pargs, attr)
    if not is_valid:
        # is_valid being false denotes there is no arg provided
        # threrefore, we will use default value
        value = default
    is_valid = not is_null_or_whitespace(value)
    return is_valid, value

def try_get_value_from_pargs_or_prompt(pargs, attr, prompt_query):
    is_valid, value = try_has_value_from_pargs(pargs, attr)
    if not is_valid:
        # is_valid being false denotes there was no arg provided
        # threrfore, we will prompt
        value = prompt(prompt_query)
    is_valid = not is_null_or_whitespace(value)
    return is_valid, value

def try_get_value_from_pargs_or_prompt_password(pargs, attr, confirm, prompt_msg=None):
    is_valid, value = try_has_value_from_pargs(pargs, attr)
    if not is_valid:
        is_valid, value = prompt_password(confirm, prompt_msg)
    return is_valid, value

def try_has_value_from_pargs(pargs, attr):
    if not hasattr(pargs, attr):
        return False, None
    string = getattr(pargs, attr)
    if string is None:
        return False, string
    return True, string

def try_get_value_from_pargs(pargs, attr):
    string = getattr(pargs, attr)
    is_valid = not is_null_or_whitespace(string)
    return is_valid, string


def validate_name(name):
    if PRINCIPAL_NAME_REGEX.search(name):
        if all([len(name) >= MIN_NAME_LENGTH, len(name) <= MAX_NAME_LENGTH]):
            return True
    return False


def trim(string):
    if not string:
        return string
    return string.strip()


def print_raw_response(response):
    if os.environ.get(SECRETSSAFE_API_RESPONSE, '').casefold() != 'true':
        return False
    decoded_content = response.content.decode()
    if is_json_string(decoded_content):
        pprint_json(response.json())
    else:
        if decoded_content:
            print(decoded_content)
    return True
