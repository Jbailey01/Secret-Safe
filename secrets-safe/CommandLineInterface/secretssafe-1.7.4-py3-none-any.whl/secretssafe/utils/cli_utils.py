import os
import sys
import ast
import json
import time
from io import BytesIO
from http import HTTPStatus
import jwt
import requests
import urllib3
from secretssafe.config import (REQUIRED_ENV_VAR_NAMES, SECRETSSAFE_AUTH_TOKEN, 
                                SECRETSSAFE_REFRESH_TOKEN, SecretsSafeConfiguration)
from secretssafe.utils.validation_utils import (print_raw_response, is_digit,
                                                try_has_value_from_pargs, is_null_or_whitespace)
from secretssafe.utils.context_utils import (persist_context_delete, get_current_context, initialize_context,
                                             persist_context_patch, load_contexts)
from secretssafe.utils.json_utils import is_json_string

def check_required_vars(log, var_map, var_name):
    if not var_map.get(var_name):
        log.error(var_name + ' configuration variable not found.')
        return False
    return True

def configure_runtime_attributes(log, config):

    # analyze environment or preset config json values for proper required arguments
    if not config.integrated:
        if not initialize_context(log, config):
            return False

    # at this point we should have our required vars in our current context
    for var_name in REQUIRED_ENV_VAR_NAMES:
        if not check_required_vars(log, config.current_context, var_name):
            return False

    # disable insecure SSL request warning if desired
    with config.get_verify_ca() as verify_ca:
        # using anything but the built in ca bundle will raise a warning
        if str(verify_ca).lower() != 'true' and config.defaults['log.logging']['level'] == 'ERROR':
            urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

    # assign endpoints relative to secretssafe host
    config.assign_endpoints()
    return True

def load_config():
    config = SecretsSafeConfiguration()
    load_contexts(config, True)
    return config

def check_for_auth_token(log, config):

    # check integrated mode (no "ssrun context" available)
    if config.integrated:
        auth_token = os.getenv('SECRETSSAFE_AUTH_TOKEN')
        if auth_token is not None:
            return True
        else:
            log.error((
            'SECRETSSAFE_AUTH_TOKEN environment variable not is set. '
            'Log-in before attempting this command.'
            ))
            return False

    if not config.get_auth_token():
        log.error((
            'SECRETSSAFE_AUTH_TOKEN not found! Please use \'ssrun login\' to login or export your '
            'token as an environment variable.'
            ))
        return False
    return True

def authenticate_user(log, config, username, password, id_provider, mfa_passcode=None):
    # need to determine which grant type, then build target URI from provider string name.
    request_data = {
        'username': username,
        'password': password,
    }
    if mfa_passcode:
        request_data['mfaPasscode'] = mfa_passcode
    authentication_url = config.authentication_url + '/' + id_provider
    auth_token, refresh_token, response = get_auth_token(authentication_url, request_data, config)
    log.info('Successfully authenticated user ' + username)
    return auth_token, refresh_token, response

def authenticate_user_with_refresh_token(log, config):
    refresh_token = config.current_context.get(SECRETSSAFE_REFRESH_TOKEN)
    request_data = {
        'refreshToken': refresh_token
    }
    authentication_url = config.authentication_url + 'refresh'
    auth_token, refresh_token = get_auth_token_using_refresh_token(authentication_url, request_data, config)
    log.info('Successfully authenticated using refresh token')
    return auth_token

def authenticate_application(log, config, api_key, application_name):
    request_data = {
        'api_key': api_key,
        'application_name': application_name
    }
    authentication_url = config.application_authentication_url
    _, _, response = get_auth_token(authentication_url, request_data, config)
    log.info('Successfully authenticated with api key ' + api_key)
    return response


# pylint: disable=inconsistent-return-statements
def get_auth_token(request_url, request_data, config):
    response = issue_request(
        request_method=requests.post,
        params={
            'url': request_url,
            'headers': {'content-type': 'application/json'},
            'json': request_data
        },
        unauthorized_message='Invalid Login Credentials')
        
    if response is None:
        return None, None, None
    if response.status_code == HTTPStatus.UNAUTHORIZED:
        eprint('401 - Invalid Login Credentials')
        return None, None, response
    print_raw_response(response)
    content = ast.literal_eval(response.content.decode())
    auth_token = content.get('access_token')
    refresh_token = content.get('refresh_token')
    config_auth_token(auth_token, refresh_token, config)
    return auth_token, refresh_token, response

def get_auth_token_using_refresh_token(request_url, request_data, config):

    response = issue_request(
        request_method=requests.post,
        params={
            'url': request_url,
            'json': request_data,
            'headers': {'content-type': 'application/json'}
        },
        unauthorized_message='Invalid Login Credentials'
    )

    if response is None:
        return None, None
    if response.status_code == HTTPStatus.UNAUTHORIZED:
        eprint('401 - Invalid refresh token. Re-authentication is required.')
        return None, None
    print_raw_response(response)
    content = ast.literal_eval(response.content.decode())
    auth_token = content.get('access_token')
    refresh_token = content.get('refresh_token')
    config_auth_token(auth_token, refresh_token, config)
    return auth_token, refresh_token


def config_auth_token(token, refresh_token, config):
    current_context = get_current_context(config)
    # if we are in integrated mode we will not be writing to disc so need to save as env
    if config.integrated:
        # set a variable so it can be used in subsequent runs if needed
        if token:
            os.environ[SECRETSSAFE_AUTH_TOKEN] = token
        if refresh_token: 
            os.environ[SECRETSSAFE_REFRESH_TOKEN] = refresh_token
    # update current context in memory
    context_patch = {
        SECRETSSAFE_AUTH_TOKEN: token,
        SECRETSSAFE_REFRESH_TOKEN: refresh_token
    }

    persist_context_patch(config, current_context.get('name'), context_patch)

def clear_auth_token(config):
    current_context = get_current_context(config)
    if SECRETSSAFE_AUTH_TOKEN not in current_context:
        return
    del current_context[SECRETSSAFE_AUTH_TOKEN]
    persist_context_delete(config, current_context.get('name'), SECRETSSAFE_AUTH_TOKEN)

# clear out previous users refresh token
def clear_refresh_token(config):
    current_context = get_current_context(config)
    if SECRETSSAFE_REFRESH_TOKEN not in current_context:
        return
    del current_context[SECRETSSAFE_REFRESH_TOKEN]
    persist_context_delete(config, current_context.get('name'), SECRETSSAFE_REFRESH_TOKEN)

def file_exists(file_path):
    if not os.path.isfile(str(file_path)):
        return False
    return True

def read_file_contents(file_path):
    if not file_exists(file_path):
        return None
    with open(file_path, 'r') as file:
        return file.read()


def load_file_bytes(file_path):
    if not file_exists(file_path):
        return None
    with open(file_path, 'rb') as file:
        return BytesIO(file.read())


def write_file_bytes(file_path, file_bytes):
    with open(str(file_path), 'wb') as output:
        output.write(file_bytes)


def issue_request(request_method, params,
                  unauthorized_message='You are not authorized to perform this action.'):
    '''
    Custom user responses for exceptions should be handled here, given the
    response code and the endpoint in question
    '''
    config = load_config()

    with config.get_verify_ca() as verify_ca:
        params['verify'] = verify_ca
        try:
            response = request_method(**params)
        except requests.exceptions.RequestException as err:
            eprint('Could not establish connection with', err.request.url)
            return None
        except OSError as err:
            eprint(err)
            return None
    if response.status_code == HTTPStatus.UNAUTHORIZED:
        return response
    try:
        response.raise_for_status()
    except requests.exceptions.HTTPError:
        decoded = response.content.decode()
        # the response should be standardized as always json
        if is_json_string(decoded) and isinstance(json.loads(decoded),dict):
            message_dict = json.loads(decoded)
            details = message_dict.get('Message')
            if details:
                # If there is just a Message field, print it nicely
                eprint(str(response.status_code) + ' - ' + details)
                if len(message_dict) > 1:
                    # if there is extra content with the message, print it too
                    message_dict.pop('Message', None)
                    eprint(json.dumps(message_dict, indent=4))
            else:
                # If there is no Message field, print it all
                eprint(str(response.status_code) + ' - ' + json.dumps(message_dict, indent=4))
        # if it isn't and is just plaintext, display anyway
        elif decoded:
            print(str(response.status_code) + ' - ' + decoded)
        # These is no content, only a status code
        else:
            print('Error - ' + str(response.status_code) + ' - (No Content)')
        return None
    return response

def issue_request_refresh(self, request_method, params,
                  unauthorized_message='You are not authorized to perform this action.'):
    try:
        # When the data is BytesIO type it becomes null after the first issue_request 
        # call so make a copy for the second call.
        if 'data' in params.keys() and isinstance(params["data"], BytesIO):
            dataCopy = params["data"].getbuffer()
        response = issue_request(request_method, params, unauthorized_message)
        if isinstance(response, type(None)):
            return
        response.raise_for_status()
    except requests.exceptions.HTTPError as err:
        if response.status_code == HTTPStatus.UNAUTHORIZED:
            if 'WWW-Authenticate' in response.headers.keys() and response.headers["WWW-Authenticate"].lower().find("token expired"):  
                # Token expired. Does this principal have a Refresh token? 
                refresh_token = self.config.current_context.get(SECRETSSAFE_REFRESH_TOKEN)
                if refresh_token is None or not refresh_token:
                    eprint(str(response.status_code) + ' - Access token expired. Re-authentication is required.')
                    return None
                auth_token = authenticate_user_with_refresh_token(self.log, self.config)
                if auth_token is not None:
                    # update Bearer with new access token
                    headers = params["headers"]
                    headers["Authorization"] = 'Bearer ' + self.config.get_auth_token()
                    params["headers"] = headers
                    # we will need a new copy of data if it is BytesIO type
                    if 'data' in params.keys() and isinstance(params["data"], BytesIO):
                        params["data"] = dataCopy
                    try:
                        response = issue_request(request_method, params, unauthorized_message)
                        if isinstance(response, type(None)):
                            return
                        response.raise_for_status()
                    except requests.exceptions.HTTPError as err:
                        if response.status_code == HTTPStatus.UNAUTHORIZED:
                            eprint(str(response.status_code) + ' - ' + unauthorized_message)
                            return None
            else:
                eprint(str(response.status_code) + ' - ' + unauthorized_message)
                return None 
    return response

def get_request_kwargs(kwargs, config, headers=None):
    kwargs.update({
        'headers': {'Authorization': 'Bearer ' + config.get_auth_token()}
        })
    if headers:
        kwargs.get('headers').update(headers)
    return kwargs


# pylint: disable=redefined-builtin,unused-argument
def excepthook(type, value, traceback):
    eprint('Unhandled error:', type, value)


def eprint(*args, **kwargs):
    print(*args, **kwargs, file=sys.stderr)


def get_from_pargs(pargs, attr):
    if hasattr(pargs, attr):
        return getattr(pargs, attr)
    return None


def try_get_filter_model_from_pargs(pargs, override_depth_when_verbose=False, depth_override=2):
    params = {}
    has_value, depth = try_has_value_from_pargs(pargs, 'depth')
    if has_value:
        if not is_digit(depth):
            return False, 'Depth'
        params['depth'] = depth

    verbose = get_from_pargs(pargs, 'verbose')
    if verbose:
        params['verbose'] = verbose
        if override_depth_when_verbose:
            params['depth'] = depth_override

    has_value, page_size = try_has_value_from_pargs(pargs, 'page_size')
    if has_value:
        if not is_digit(page_size):
            return False, 'Page size'
        params['page_size'] = page_size

    has_value, page_number = try_has_value_from_pargs(pargs, 'page_number')
    if has_value:
        if not is_digit(page_number):
            return False, 'Page number'
        params['page_number'] = page_number

    has_value, sort = try_has_value_from_pargs(pargs, 'sort_by')
    if has_value:
        if is_null_or_whitespace(sort):
            return False, 'Sort by'
        params['sort'] = sort

    return True, params


def get_logged_in_principal(log, config):
    token = config.current_context.get(SECRETSSAFE_AUTH_TOKEN)
    try:
        decoded = jwt.decode(token, options={'verify_signature':False, 'verify_aud':False})
    except jwt.exceptions.DecodeError:
        log.error('Malformed authorization token. Please log in.')
        return None
    current_time = int(time.time())
    expiry_time = decoded.get('exp')
    if current_time > expiry_time:
        log.error('Authorization token expired. Please log in.')
        return None
    try:
        principal = json.loads(decoded.get('bt_principal'))
    except json.decoder.JSONDecodeError:
        log.error(('Authorization token provided malformed principal details. '
                   'Please log in.'))
        return None
    return Principal(
        principal.get('IdentityProvider'),
        principal.get('PrincipalType'),
        principal.get('Name')
    )


def get_dict_from_iter(key, value, iterable):
    return next((item for item in iterable if item.get(key) == value), None)


class Principal:

    def __init__(self, identity_provider, principal_type, name):
        self.identity_provider = identity_provider
        self.principal_type = principal_type
        self.name = name


ASCII_BANNER = '''
  _________                            __             _________       _____
 /   _____/ ____   ___________   _____/  |_  ______  /   _____/____ _/ ____\\____
 \\_____  \\_/ __ \\_/ ___\\_  __ \\_/ __ \\   __\\/  ___/  \\_____  \\__   \\    __\\/ __ \\
 /        \\  ___/\\  \\___|  | \\/\\  ___/|  |  \\___ \\   /        \\/ __ \\|  | \\  ___/
/_______  /\\___  >\\___  >__|    \\___  >__| /____  > /_______  (____  /__|  \\___  >
        \\/     \\/     \\/            \\/          \\/          \\/     \\/          \\/

'''
