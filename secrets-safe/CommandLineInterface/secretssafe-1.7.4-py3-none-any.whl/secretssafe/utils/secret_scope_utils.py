import requests

from secretssafe.utils.validation_utils import is_null_or_whitespace
from secretssafe.utils.cli_utils import issue_request_refresh, get_request_kwargs, load_file_bytes

def full_url_from_secret_uri(application_controller, secret_uri):
    secret_uri = secret_uri.lstrip('/')
    full_url = '{}/{}'.format(application_controller.config.secret_url, secret_uri)
    return full_url    

def try_is_scope(uri, verb):
    if is_null_or_whitespace(uri):
        return False, ''
    if is_secret(uri):
        return False, ('To ' + verb + ' a secret use the '
                       '\'secret ' + verb + '\' command')
    return True, ''

def try_is_secret(uri, verb):
    if is_null_or_whitespace(uri):
        return False, ''
    if is_scope(uri):
        return False, ('To ' + verb + ' a scope use the '
                       '\'scope ' + verb + '\' command')
    return True, ''


def is_scope(uri):
    return not is_secret(uri)

def is_secret(uri):
    uri_segments = uri.split('/')
    tail = uri_segments[len(uri_segments)-1]
    if ':' not in tail:
        return False
    return True


def parse_secret_crud_args(args, secret_url):
    uri = args.URI[0].lstrip('/')
    url = secret_url + '/' + uri
    return url, uri


def parse_metadata_crud_args(args, api_root_url):
    uri = args.URI[0].lstrip('/')
    return (
        api_root_url + '/' + uri + '/_metadata',
        uri,
        getattr(args, 'metadata_name', None),
        getattr(args, 'metadata_value', None)
        )

def get_secret(application_controller, secret_uri):
    secret_uri = secret_uri.lstrip('/')
    full_url = full_url_from_secret_uri(application_controller, secret_uri)
    response = issue_request_refresh(
        application_controller,
        request_method=requests.get,
        params=get_request_kwargs({'url': full_url}, application_controller.config)
    )
    if not response:
        return
    return response.content

def create_secret_with_bytes(application_controller, secret_uri, secret_data, update_existing):
    full_url = full_url_from_secret_uri(application_controller, secret_uri)
    request_method = requests.put if update_existing else requests.post
    response = issue_request_refresh(
        application_controller,
        request_method=request_method,
        params=get_request_kwargs(
            kwargs={'url': full_url, 'data': secret_data},
            config=application_controller.config,
            headers={'Content-Type': 'application/octet-stream'}
        )
    )
    return response

def create_secret_with_generator(application_controller, secret_uri, generator_name, update_existing):
    full_url = full_url_from_secret_uri(application_controller, secret_uri)
    request_method = requests.put if update_existing else requests.post
    response = issue_request_refresh(application_controller,
        request_method=request_method,
        params=get_request_kwargs(
            kwargs={'url': full_url, 'params': {'generator': generator_name}},
            config=application_controller.config,
            headers={'Content-Type': 'application/octet-stream'}
        )
    )
    return response

def create_secret_with_file(application_controller, secret_uri, file_path, update_existing):
    file_bytes = load_file_bytes(file_path)
    if not file_path:
        return
    return create_secret_with_bytes(application_controller, secret_uri, file_bytes, update_existing)
