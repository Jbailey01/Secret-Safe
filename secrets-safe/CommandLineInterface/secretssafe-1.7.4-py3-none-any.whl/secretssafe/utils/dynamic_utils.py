from secretssafe.utils.cli_utils import issue_request_refresh, get_request_kwargs, load_file_bytes
import requests

def create_dynamic_account(application_controller, provider, account_definition, input_file):
    file_bytes = None
    if input_file:
        file_bytes = load_file_bytes(input_file)
    return create_dyanmic_account_with_bytes(application_controller, provider,
                                             account_definition, file_bytes)

def create_dyanmic_account_with_bytes(application_controller, provider, account_definition,
                                      input_bytes):
    request_uri = '{}/{}/{}/'.format(application_controller.config.dynamic_url,
                                     provider, account_definition)
    keyword_arguments = {'url': request_uri}

    if input_bytes:
        keyword_arguments['data'] = input_bytes

    response = issue_request_refresh(
        application_controller,
        request_method=requests.post,
        params=get_request_kwargs(
            kwargs=keyword_arguments,
            config=application_controller.config,
            headers={'content-type': 'application/json'}
        )
    )
    return response
