import requests
from cement import ex
from secretssafe.controllers.base import SecretsSafeBaseController
from secretssafe.config import ALL
from secretssafe.utils.cli_utils import *
from secretssafe.utils.validation_utils import *

DESC = 'Manage applications.'


class ApplicationController(SecretsSafeBaseController):

    class Meta:
        label = 'application'
        stacked_on = 'base'
        stacked_type = 'nested'
        description = DESC
        help = ': ' + DESC

    @ex(hide=True)
    def _default(self):
        super()._display_help('application')

    @ex(
        arguments=[
            (['-n', '--name'],
             {'help': ': Application Name.',
              'dest': 'application_name',
              'required': False}),
            ],
        help=''': Create an application. Returns the associated applications
                API key.''')
    def create(self):
        pargs = self.app.pargs
        is_valid, application_name = try_get_value_from_pargs_or_prompt(
            pargs, 'application_name', 'Application Name:')
        if not is_valid:
            log_invalid_error_message(self.log, 'Application Name')
            return
        response = issue_request_refresh(self,
            request_method=requests.post,
            params=get_request_kwargs(
                kwargs={
                    'url': self.config.internal_application_url,
                    'json': {
                        'name': application_name
                    }
                },
                config=self.config
            )
        )
        if not response:
            return
        self.log.info('Application ' + application_name + ' has been created.')
        pprint_json(response.json())

    @ex(
        arguments=[
            (['-n', '--name'],
             {'help': ''': If a name is specified, only that application is returned and 
                         sorting and pagination options are ignored. If no name is specified, 
                         a list of applications is returned with sorting and pagination options 
                         (if specified) applied.''',
              'dest': 'application_name',
              'required': False}),
            (['-v', '--verbose'],
             {'help': ''': Verbose output. Use the -v flag to get a full listing of applications
                         attributes. Otherwise, a slim view of each application is returned.''',
              'action': 'store_true'}),
            (['-ps', '--page-size'],
             {'help': ''': Specifies the maximum number of elements to return in the application
                         listing. Value must be between 1 and 100. Note, all group membership
                         listings will also be limited to this page size.''',
              'dest': 'page_size',
              'required': False}),
            (['-pn', '--page_number'],
             {'help': ''': Specifies the page number (1-based) of results to return.''',
              'dest': 'page_number',
              'required': False}),
            (['-sb', '--sort-by'],
             {'help': ''': Specifies the sort order for the application listing. This is defined
                         as a single field or comma delimeted list of fields with the sort order
                         (one of:ace|desc) specified in brackets after each and mentioned in single
                         quotes. For example: 'Name(desc)' OR 'Name(desc)','Url(asc)'.''',
              'dest': 'sort_by',
              'required': False})
            ],
        help=''': Return list of applications for given identity provider or the details of the
                specified application.''')
    def get(self):
        pargs = self.app.pargs
        has_value, application_name = try_has_value_from_pargs(pargs, 'application_name')
        if not has_value:
            uri = 'internal/application/'
        else:
            is_valid = not is_null_or_whitespace(application_name)
            if not is_valid:
                log_invalid_error_message(self.log, 'Application Name')
                return
            uri = 'internal/application/' + application_name
        is_valid, model_data = try_get_filter_model_from_pargs(pargs, True, 3)
        if not is_valid:
            log_invalid_error_message(self.log, model_data)
            return
        response = issue_request_refresh(self,
            request_method=requests.get,
            params=get_request_kwargs(
                kwargs={
                    'url': self.config.principal_url + '/' + uri,
                    'params': model_data
                },
                config=self.config
            )
        )
        if not response:
            return
        pprint_json(response.json())

    @ex(
        arguments=[
            (['-n', '--name'],
             {'help': ': Name of the application to delete.',
              'dest': 'application_name',
              'required': False}),
            ],
        help=': Delete an application.')
    def delete(self):
        pargs = self.app.pargs
        is_valid, application_name = try_get_value_from_pargs_or_prompt(
            pargs, 'application_name', 'Application Name:')
        if not is_valid:
            log_invalid_error_message(self.log, 'Application Name')
            return
        url = self.config.internal_application_url + '/' + application_name
        response = issue_request_refresh(self,
            request_method=requests.delete,
            params=get_request_kwargs(
                kwargs={'url': url},
                config=self.config
            )
        )
        if not response:
            return
        print_raw_response(response)
        self.log.info('Application ' + application_name + ' has been deleted.')

    @ex(
        arguments=[
            (['-n', '--name'],
             {'help': ': Name of the application.',
              'dest': 'application_name',
              'required': False}),
            ],
        help=': Regenerate a new api key for a given application.')
    def regenerate_api_key(self):
        pargs = self.app.pargs
        is_valid, application_name = try_get_value_from_pargs_or_prompt(
            pargs, 'application_name', 'Application Name:')
        if not is_valid:
            log_invalid_error_message(self.log, 'Application Name')
            return
        url = self.config.internal_application_url + '/' + application_name + '/api_key'
        response = issue_request_refresh(self,
            request_method=requests.post,
            params=get_request_kwargs({'url': url}, self.config)
        )
        if not response:
            return
        print(response.content.decode())
        self.log.info('API Key for Application ' + application_name + ' has been regenerated.')
