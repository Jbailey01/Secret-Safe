import requests
from cement import ex
from secretssafe.controllers.base import SecretsSafeBaseController
from secretssafe.config import ALL
from secretssafe.utils.cli_utils import *
from secretssafe.utils.validation_utils import *
from secretssafe.utils.json_utils import *

DESC = 'Manage users.'


class UserController(SecretsSafeBaseController):

    class Meta:
        label = 'user'
        stacked_on = 'base'
        stacked_type = 'nested'
        description = DESC
        help = ': ' + DESC

    @ex(hide=True)
    def _default(self):
        super()._display_help('user')

    @ex(
        arguments=[
            (['-n', '--name'],
             {'help': ': User name for created user.',
              'dest': 'username',
              'required': False}),
            (['-p', '--password'],
             {'help': ': Password for created user',
              'dest': 'password',
              'required': False}),
            (['-i', '--identity-provider'],
             {'help': ': Identity provider name. Defaults to internal if not specified.',
              'dest': 'identity_provider',
              'required': False}),
            ],
        help=': Create a user.')
    def create(self):
        pargs = self.app.pargs
        is_valid, username = try_get_value_from_pargs_or_prompt(
            pargs, 'username', 'Username:')
        if not is_valid:
            log_invalid_error_message(self.log, 'Username')
            return
        is_valid, id_provider = try_get_value_from_pargs_or_default(
            pargs, 'identity_provider', 'internal')
        if not is_valid:
            log_invalid_error_message(self.log, 'Identity provider')
            return
        # internal identity provider requires password
        if id_provider == 'internal':
            is_valid, password = try_get_value_from_pargs_or_prompt_password(
                pargs, 'password', 'Password:')
            if not is_valid:
                log_invalid_error_message(self.log, 'Password')
                return
        else: 
            password = ""                
        create_user_url = self.config.principal_url + '/' + id_provider + '/user'
        response = issue_request_refresh(self,
            request_method=requests.post,
            params=get_request_kwargs(
                kwargs={
                    'url': create_user_url,
                    'json': {'username': username, 'password': password}
                },
                config=self.config
            )
        )
        if not response:
            return
        self.log.info('User ' + username + ' has been created.')
        pprint_json(response.json())

    @ex(
        arguments=[
            (['-n', '--name'],
             {'help': ''': If a name is specified, only that user is returned and sorting and 
                         pagination options are ignored. If no name is specified, a list of users 
                         is returned with sorting and pagination options (if specified) applied.''',
              'dest': 'username',
              'required': False}),
            (['-i', '--identity-provider'],
             {'help': ': Identity provider name. Defaults to internal if not specified.',
              'dest': 'identity_provider',
              'required': False}),
            (['-v', '--verbose'],
             {'help': ''': Verbose output. Use the -v flag to get a full listing of users
                         attributes. Otherwise, a slim view of each user is returned.''',
              'action': 'store_true'}),
            (['-ps', '--page-size'],
             {'help': ''': Specifies the maximum number of elements to return in the user listing. 
                         Value must be between 1 and 100. Note, all  group membership listings 
                         will also be limited to this page size.''',
              'dest': 'page_size',
              'required': False}),
            (['-pn', '--page_number'],
             {'help': ''': Specifies the page number (1-based) of results to return.''',
              'dest': 'page_number',
              'required': False}),
            (['-sb', '--sort-by'],
             {'help': ''': Specifies the sort order for the user listing. This is defined
                         as a single field or comma delimeted list of fields with the sort order
                         (one of:ace|desc) specified in brackets after each and mentioned in single
                         quotes. For example: 'Name(desc)' OR 'Name(desc)','Url(asc)'.''',
              'dest': 'sort_by',
              'required': False})
            ],
        help=''': Return list of users for given identity provider or the details of the specified
                user.''')
    def get(self):
        pargs = self.app.pargs
        is_valid, id_provider = try_get_value_from_pargs_or_default(
            pargs, 'identity_provider', 'internal')
        if not is_valid:
            log_invalid_error_message(self.log, 'Identity provider')
            return
        has_value, username = try_has_value_from_pargs(pargs, 'username')
        if not has_value:
            uri = id_provider + '/user'
        else:
            is_valid = not is_null_or_whitespace(username)
            if not is_valid:
                log_invalid_error_message(self.log, 'Username')
                return
            uri = id_provider + '/user/' + username
        is_valid, model_data = try_get_filter_model_from_pargs(pargs, True, 3)
        if not is_valid:
            log_invalid_error_message(self.log, model_data)
            return
        response = issue_request_refresh(self,
            request_method=requests.get,
            params=get_request_kwargs(
                kwargs={'url': self.config.principal_url + '/' + uri, 'params': model_data},
                config=self.config
            )
        )
        if not response:
            return
        pprint_json(response.json())

    @ex(
        arguments=[
            (['-n', '--name'],
             {'help': ': Name of the user whose password will change.',
              'dest': 'username',
              'required': False}),
            ],
        help=': Change the password for a specified user.')
    def change_password(self):
        is_valid, username = try_get_value_from_pargs_or_prompt(
            self.app.pargs, 'username', 'Username:')
        if not is_valid:
            log_invalid_error_message(self.log, 'Username')
            return
        if not validate_name(username):
            log_invalid_error_message(self.log, 'Username')
            return
        current_authenticated_principal = get_logged_in_principal(self.log, self.config)
        request_json = {}
        # only prompt for current password if you are changing your own
        if current_authenticated_principal.name == username:
            is_valid, prompt_result1 = prompt_password(False, 'Current password')
            if not is_valid:
                self.log.error(prompt_result1)
                return
            request_json['currentPassword'] = prompt_result1
        is_valid, prompt_result2 = prompt_password(True, 'New password')
        if not is_valid:
            self.log.error(prompt_result2)
            return
        request_json['newPassword'] = prompt_result2
        url = self.config.internal_user_url + '/' + username + '/password'
        response = issue_request_refresh(self,
            request_method=requests.put,
            params=get_request_kwargs(
                kwargs={'url': url, 'json': request_json},
                config=self.config
            )
        )
        if not response:
            return
        print_raw_response(response)
        self.log.info('Password for user ' + username + ' has been changed.')

    @ex(
        arguments=[
            (['-n', '--name'],
             {'help': ': Name of user to delete.',
              'dest': 'username',
              'required': False}),
            (['-i', '--identity-provider'],
             {'help': ': Identity provider name. Defaults to internal if not specified.',
              'dest': 'identity_provider',
              'required': False}),
            ],
        help=': Delete a user.')
    def delete(self):
        pargs = self.app.pargs
        is_valid, username = try_get_value_from_pargs_or_prompt(
            pargs, 'username', 'Username:')
        if not is_valid:
            log_invalid_error_message(self.log, 'Username')
            return
        is_valid, id_provider = try_get_value_from_pargs_or_default(
            pargs, 'identity_provider', 'internal')
        if not is_valid:
            log_invalid_error_message(self.log, 'Identity provider')
            return
        url = id_provider + '/user/' + username
        response = issue_request_refresh(self,
            request_method=requests.delete,
            params=get_request_kwargs(
                kwargs={'url': self.config.principal_url + '/' + url},
                config=self.config
            )
        )
        if not response:
            return
        print_raw_response(response)
        self.log.info('User ' + username + ' has been deleted.')
