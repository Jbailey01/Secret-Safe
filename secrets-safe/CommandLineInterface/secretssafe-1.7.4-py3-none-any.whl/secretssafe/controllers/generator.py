import sys
import json
from http import HTTPStatus
import requests
from cement import ex
from secretssafe.controllers.base import SecretsSafeBaseController
from secretssafe.config import ALL
from secretssafe.utils.cli_utils import *
from secretssafe.utils.validation_utils import *

DESC = 'Manage generators.'


class GeneratorController(SecretsSafeBaseController):

    class Meta:
        label = 'generator'
        stacked_on = 'base'
        stacked_type = 'nested'
        description = DESC
        help = ': ' + DESC

    @ex(hide=True)
    def _default(self):
        super()._display_help('generator')

    @ex(
        arguments=[
            (['-f', '--file-path'],
             {'help': ': Path to the generator configuration file.',
              'dest': 'file_path',
              'required': True})
            ],
        help=': Create a generator configuration.')

    def create(self):
        pargs = self.app.pargs
        is_valid, file_path = try_get_value_from_pargs(pargs, 'file_path')
        if not is_valid:
            log_invalid_error_message(self.log, 'Generator File')
            return
        data = read_file_contents(file_path)
        response = issue_request_refresh(self,
            request_method=requests.post,
            params=get_request_kwargs(
                kwargs={'url': self.config.generator_url, 'data': data},
                config=self.config,
                headers={'content-type': 'application/json'}
                )
            )
        if not response:
            return
        if response.status_code == HTTPStatus.CREATED:
            self.log.info('Generator created:')
            if print_raw_response(response):
                return
            self.log.info(json.dumps(response.json(), indent=4))

    @ex(
        arguments=[
            (['-n', '--name'],
             {'help': ''': The name of the generator to display. If no name is specified, all
                         configured generators are listed.''',
              'dest': 'generator_name',
              'required': False}),
            ],
        help=': Return list of all generators or the configuration of a specific generator.')

    def get(self):
        pargs = self.app.pargs
        has_value, generator_name = try_has_value_from_pargs(pargs, 'generator_name')
        if not has_value:
            request_url = self.config.generator_url
        else:
            if is_null_or_whitespace(generator_name):
                log_invalid_error_message(self.log, 'Generator Name')
                return
            request_url = '{}/{}'.format(self.config.generator_url, generator_name)
        response = issue_request_refresh(self,
            request_method=requests.get,
            params=get_request_kwargs(
                {'url': request_url},
                self.config
                )
        )
        if not response or response.status_code != HTTPStatus.OK:
            return
        generator_configurations = response.json()
        print(json.dumps(generator_configurations, indent=4))

    @ex(
        arguments=[
            (['-f', '--file-path'],
             {'help': ': Path to the generator configuration file.',
              'dest': 'file_path',
              'required': True}),
            (['-n', '--name'],
             {'help': ': The name of the generator to be updated.',
              'dest': 'generator_name',
              'required': True})
            ],
        help=': Update an existing generator configuration.')

    def update(self):
        pargs = self.app.pargs
        is_valid, generator_name = try_get_value_from_pargs(pargs, 'generator_name')
        if not is_valid:
            log_invalid_error_message(self.log, 'Generator Name')
            return
        is_valid, file_path = try_get_value_from_pargs(pargs, 'file_path')
        if not is_valid:
            log_invalid_error_message(self.log, 'Generator File')
            return
        data = read_file_contents(file_path)
        response = issue_request_refresh(self,
            request_method=requests.put,
            params=get_request_kwargs(
                kwargs={'url': self.config.generator_url + '/' + generator_name, 'data': data},
                config=self.config,
                headers={'content-type': 'application/json'}
                )
            )
        if not response:
            return
        if response.status_code == HTTPStatus.OK:
            self.log.info('Generator ' + generator_name + ' updated.')
            if print_raw_response(response):
                return
            if is_json_string(response.content.decode()):
                self.log.info(json.dumps(response.json(), indent=4))

    @ex(
        arguments=[
            (['-n', '--name'],
             {'help': ': The name of the generator to be deleted.',
              'dest': 'generator_name',
              'required': True}),
            ],
        help=': Delete a generator configuration.')

    def delete(self):
        pargs = self.app.pargs
        is_valid, generator_name = try_get_value_from_pargs(pargs, 'generator_name')
        if not is_valid:
            log_invalid_error_message(self.log, 'Generator Name')
            return
        response = issue_request_refresh(self,
            request_method=requests.delete,
            params=get_request_kwargs(
                {'url': self.config.generator_url + '/' + generator_name},
                self.config
            )
        )
        if not response:
            return
        print_raw_response(response)
        self.log.info('Generator ' + generator_name + ' has been deleted')
    
    # This operation is being remove from the current release as per 
    #   PRODUCT BACKLOG ITEM 213803 (https://dev.azure.com/beyondtrust/DevOps%20Secrets%20Safe/_workitems/edit/213803)
    # @ex(
    #     arguments=[
    #         (['-n', '--name'],
    #          {'help': ': The name of the generator used to generate the value.',
    #           'dest': 'generator_name',
    #           'required': True}),
    #         (['-f', '--file-path'],
    #          {'help': ': Destination file path.',
    #           'dest': 'file_path',
    #           'required': False})
    #         ],
    #     help=': Generate a value using the specified generator.')
    # def generate(self):
    #     generator_name = get_from_pargs(self.app.pargs, 'generator_name')
    #     file_path = get_from_pargs(self.app.pargs, 'file_path')
    #     if not generator_name:
    #         self.log.error('Must provide an generator name for generation.')
    #         return
    #     response = issue_request(
    #         request_method=requests.post,
    #         params=get_request_kwargs(
    #             {'url': self.config.generator_url + '/' + generator_name + '/generate'},
    #             self.config
    #         )
    #     )
    #     if not response:
    #         return
    #     content = response.content
    #     if self.config.integrated:
    #         RawOutput.set_output(content)
    #         return
    #     if file_path:
    #         write_file_bytes(file_path, content)
    #         return
    #     if not sys.stdout.isatty():
    #         sys.stdout.buffer.write(content)
    #         return
    #     try:
    #         data = content.decode()
    #         if is_json_string(data):
    #             data = format_json_string(data)
    #     except UnicodeDecodeError:
    #         data = content
    #     print(data)
