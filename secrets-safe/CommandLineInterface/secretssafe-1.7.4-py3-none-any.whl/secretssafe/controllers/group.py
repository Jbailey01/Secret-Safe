import requests
from cement import ex
from secretssafe.controllers.base import SecretsSafeBaseController
from secretssafe.config import ALL, INTERNAL
from secretssafe.utils.cli_utils import *
from secretssafe.utils.validation_utils import *

DESC = 'Manage groups.'


class GroupController(SecretsSafeBaseController):

    class Meta:
        label = 'group'
        stacked_on = 'base'
        stacked_type = 'nested'
        description = DESC
        help = ': ' + DESC

    @ex(hide=True)
    def _default(self):
        super()._display_help('group')

    @ex(
        arguments=[
            (['-n', '--name'],
             {'help': ': Group name.',
              'dest': 'group_name',
              'required': False}),
            (['-i', '--identity-provider'],
             {'help': ': Identity provider name. Defaults to internal.',
              'dest': 'identity_provider',
              'required': False}),
            (['-u', '--unique-id'],
             {'help': ''': Unique identifier string for this group. For groups from remote
                         identity providers, this ID must match the unique identifier from the
                         external provider to enable membership synchronization. If blank, a new
                         GUID is generated for this field.''',
              'dest': 'unique_id',
              'required': False}),
            ],
        help=': Create a group.')
    def create(self):
        pargs = self.app.pargs
        is_valid, group_name = try_get_value_from_pargs_or_prompt(
            pargs, 'group_name', 'Group name:')
        if not is_valid:
            log_invalid_error_message(self.log, 'Group name')
            return
        is_valid, id_provider = try_get_value_from_pargs_or_default(
            pargs, 'identity_provider', 'internal')
        if not is_valid:
            log_invalid_error_message(self.log, 'Identity provider')
            return
        unique_id = get_from_pargs(pargs, 'unique_id') or ''
        response = issue_request_refresh(self,
            request_method=requests.post,
            params=get_request_kwargs(
                kwargs={
                    'url': self.config.principal_url + '/' + id_provider + '/group',
                    'json': {
                        'name': group_name,
                        'uniqueIdentifier': unique_id
                    }
                },
                config=self.config
            )
        )
        if not response:
            return
        self.log.info('Group ' + group_name + ' has been created.')
        pprint_json(response.json())

    @ex(
        arguments=[
            (['-n', '--name'],
             {'help': ''': If a name is specified, only that group is returned and sorting and 
                         pagination options are ignored. If no name is specified, a list of groups 
                         is returned with sorting and pagination options (if specified) applied.''',
              'dest': 'group_name',
              'required': False}),
            (['-i', '--identity-provider'],
             {'help': ': Identity provider name. Defaults to internal if not specified.',
              'dest': 'identity_provider',
              'required': False}),
            (['-v', '--verbose'],
             {'help': ''': Verbose output. Use the -v flag to get a full listing of group
                         attributes. Otherwise, a slim view of each group is returned.''',
              'action': 'store_true'}),
            (['-ps', '--page-size'],
             {'help': ''': Specifies the maximum number of elements to return in the group listing. 
                         Value must be between 1 and 100. Note, all user/application membership 
                         listings will also be limited to this page size.''',
              'dest': 'page_size',
              'required': False}),
            (['-pn', '--page_number'],
             {'help': ''': Specifies the page number (1-based) of results to return.''',
              'dest': 'page_number',
              'required': False}),
            (['-sb', '--sort-by'],
             {'help': ''': Specifies the sort order for the group listing. This is defined
                         as a single field or comma delimeted list of fields with the sort order
                         (one of:ace|desc) specified in brackets after each and mentioned in single
                         quotes. For example: 'Name(desc)' OR 'Name(desc)','Url(asc)'.''',
              'dest': 'sort_by',
              'required': False})
            ],
        help=''': Return list of groups for given identity provider or the details of the
                specified group.''')
    def get(self):
        pargs = self.app.pargs
        is_valid, id_provider = try_get_value_from_pargs_or_default(
            pargs, 'identity_provider', 'internal')
        if not is_valid:
            log_invalid_error_message(self.log, 'Identity provider')
            return
        has_value, group_name = try_has_value_from_pargs(pargs, 'group_name')
        if not has_value:
            uri = id_provider + '/group'
        else:
            is_valid = not is_null_or_whitespace(group_name)
            if not is_valid:
                log_invalid_error_message(self.log, 'Group name')
                return
            uri = id_provider + '/group/' + group_name
        is_valid, model_data = try_get_filter_model_from_pargs(pargs)
        if not is_valid:
            log_invalid_error_message(self.log, model_data)
            return
        response = issue_request_refresh(self,
            request_method=requests.get,
            params=get_request_kwargs(
                kwargs={
                    'url': self.config.principal_url + '/' + uri,
                    'params': model_data
                },
                config=self.config
            )
        )
        if not response:
            return
        pprint_json(response.json())

    @ex(
        arguments=[
            (['-n', '--name'],
             {'help': ': Name of the group to update.',
              'dest': 'group_name',
              'required': True}),
            (['-p', '--principal-resources'],
             {'help': ': Comma seperated list of principal resources.',
              'dest': 'principal_resources',
              'required': True}),
            ],
        help=': Add principals to a group.')
    def add_member(self):
        pargs = self.app.pargs
        is_valid, group_name = try_get_value_from_pargs_or_prompt(
            pargs, 'group_name', 'Group name:')
        if not is_valid:
            log_invalid_error_message(self.log, 'Group name')
            return
        is_valid, res_to_add = try_get_value_from_pargs_or_prompt(pargs, 'principal_resources',
                                                        'Enter resources (comma separated format):')
        if not is_valid:
            log_invalid_error_message(self.log, 'Principal name')
            return
        response = issue_request_refresh(self,
            request_method=requests.post,
            params=get_request_kwargs(
                kwargs={
                    'url': self.config.group_url + '/' + group_name + '/members',
                    'json': {'principalResourcesToAdd': res_to_add.split(',')}
                },
                config=self.config
            )
        )
        if not response:
            return
        print_raw_response(response)
        self.log.info('Principals have been added to group ' + group_name + '.')

    @ex(
        arguments=[
            (['-n', '--name'],
             {'help': ': Name of the group to update.',
              'dest': 'group_name',
              'required': False}),
            (['-p', '--principal-resources'],
             {'help': ': Comma seperated list of principal resources.',
              'dest': 'principal_resources',
              'required': False})
            ],
        help=': Add or remove principals from a group.')
    def remove_member(self):
        pargs = self.app.pargs
        is_valid, group_name = try_get_value_from_pargs_or_prompt(
            pargs, 'group_name', 'Group name:')
        if not is_valid:
            log_invalid_error_message(self.log, 'Group name')
            return
        is_valid, res_to_remove = try_get_value_from_pargs_or_prompt(pargs, 'principal_resources',
                                                                     'Enter resources (comma separated format):')
        if not is_valid:
            log_invalid_error_message(self.log, 'Principal name')
            return
        response = issue_request_refresh(self,
            request_method=requests.delete,
            params=get_request_kwargs(
                kwargs={
                    'url': self.config.group_url + '/' + group_name + '/members',
                    'json': {
                        'principalResourcesToRemove': res_to_remove.split(',')
                        }
                },
                config=self.config
            )
        )
        if not response:
            return
        print_raw_response(response)
        self.log.info('Principals have been removed from group ' + group_name + '.')

    @ex(
        arguments=[
            (['-n', '--name'],
             {'help': ': Name of the group to delete.',
              'dest': 'group_name',
              'required': False}),
            (['-i', '--identity-provider'],
             {'help': ''': Identity provider name. Defaults to internal.''',
              'dest': 'identity_provider',
              'required': False}),
            ],
        help=': Delete a group.')
    def delete(self):
        pargs = self.app.pargs
        is_valid, group_name = try_get_value_from_pargs_or_prompt(
            pargs, 'group_name', 'Group name:')
        if not is_valid:
            log_invalid_error_message(self.log, 'Group name')
            return
        is_valid, id_provider = try_get_value_from_pargs_or_default(
            pargs, 'identity_provider', 'internal')
        if not is_valid:
            log_invalid_error_message(self.log, 'Identity provider')
            return
        url = id_provider + '/group/' + group_name
        response = issue_request_refresh(self,
            request_method=requests.delete,
            params=get_request_kwargs(
                kwargs={'url': self.config.principal_url + '/' + url},
                config=self.config
            )
        )
        if not response:
            return
        print_raw_response(response)
        self.log.info('Group ' + group_name + ' has been deleted')
