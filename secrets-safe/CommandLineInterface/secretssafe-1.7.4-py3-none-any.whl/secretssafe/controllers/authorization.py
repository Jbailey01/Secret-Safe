import json
from http import HTTPStatus
import requests
from cement import ex
from secretssafe.controllers.base import SecretsSafeBaseController
from secretssafe.utils.cli_utils import *
from secretssafe.utils.validation_utils import *

DESC = 'Manage access control entries.'


class AuthorizationController(SecretsSafeBaseController):

    class Meta:
        label = 'authorization'
        stacked_on = 'base'
        stacked_type = 'nested'
        description = DESC
        help = ': ' + DESC

    @ex(hide=True)
    def _default(self):
        super()._display_help('authorization')

    @ex(
        arguments=[
            (['resource_uri'], {'help': ': URI of resource.'}),
            (['-p', '--principal-uri'],
             {'help': ': URI of principal authorization applies to.',
              'dest': 'principal_uri',
              'required': True}),
            (['-o', '--operations'],
             {'help': ': Operations authorization applies to - comma separated.',
              'dest': 'operations',
              'required': True}),
            (['-a', '--access'],
             {'help': ': Set to allow to grant authorization or deny to revoke.',
              'dest': 'access',
              'required': True}),
            (['-i', '--identity-authority'],
             {'help': ': Identity authority for principal.',
              'dest': 'id_authority',
              'required': False})
            ],
        help=''': Creates an access control entry that grants or denies the privilege to a set of
                operations on a specific resource for a principal.''')
    def create(self):
        self._create_update_authorization('create')

    @ex(
        arguments=[
            (['-p', '--principal-uri'],
             {'help': ': URI of principal authorizations apply to.',
              'dest': 'principal_uri',
              'required': False}),
            (['-v', '--verbose'],
             {'help': ''': Verbose output. Set to true to get a full listing of principal and
                         access control attributes. Otherwise, a slim view of each principal and
                         their access control is returned.''',
              'action': 'store_true'}),
            (['-ps', '--page-size'],
             {'help': ''': Specifies the maximum number of elements to return in the principal
                         listing. Value must be between 1 and 100. Note, access control listings 
                         will also be limited to this page size.''',
              'dest': 'page_size',
              'required': False}),
            (['-pn', '--page_number'],
             {'help': ''': Specifies the page number (1-based) of results to return.''',
              'dest': 'page_number',
              'required': False}),
            (['-sb', '--sort-by'],
             {'help': ''': Specifies the sort order for the principal listing. This is defined
                         as a single field or comma delimeted list of fields with the sort order
                         (one of:ace|desc) specified in brackets after each and mentioned in single
                         quotes. For example: 'Name(desc)' OR 'Name(desc)','Url(asc)'.''',
              'dest': 'sort_by',
              'required': False})
            ],
        help=': List Access Control Entries by Principal.')
    def get(self):
        pargs = self.app.pargs
        has_value, principal_uri = try_has_value_from_pargs(pargs, 'principal_uri')
        if has_value:
            is_valid, principal_uri = validate_resource_uri('principal', principal_uri)
            if not is_valid:
                log_invalid_error_message(self.log, 'Principal URI')
                return
            url = self.config.authorization_url + '/' + principal_uri
        else:
            url = self.config.authorization_url
        is_valid, model_data = try_get_filter_model_from_pargs(pargs)
        if not is_valid:
            log_invalid_error_message(self.log, model_data)
            return
        request_kwargs = {
            'url': url,
            'params': model_data
        }
        response = issue_request_refresh(self,
            request_method=requests.get,
            params=get_request_kwargs(request_kwargs, self.config)
        )

        if not response:
            return
        if response.status_code == HTTPStatus.OK:
            print(json.dumps(response.json(), indent=4))

    @ex(
        arguments=[
            (['resource_uri'], {'help': ': URI of resource.'}),
            (['-p', '--principal-uri'],
             {'help': ': URI of principal authorization applies to.',
              'dest': 'principal_uri',
              'required': True}),
            (['-o', '--operations'],
             {'help': ': Operations authorization applies to - comma separated',
              'dest': 'operations',
              'required': True}),
            (['-a', '--access'],
             {'help': ': Set to allow to grant authorization or deny to revoke.',
              'dest': 'access',
              'required': True}),
            (['-i', '--identity-authority'],
             {'help': ': Identity authority for principal.',
              'dest': 'id_authority',
              'required': False})
            ],
        help=''': Updates an access control entry that grants or denies the privilege to a set of
                operations on a specific resource for a principal.''')
    def update(self):
        self._create_update_authorization('update')

    # pylint: disable=redefined-builtin,invalid-name
    @ex(
        arguments=[
            (['-i', '--id'],
             {'help': ': The ID of the access control entry to be deleted.',
              'dest': 'id',
              'required': True})
            ],
        help=': Delete an access control entry.')
    def delete(self):
        pargs = self.app.pargs
        is_valid, id = try_get_value_from_pargs(pargs, 'id')
        if not is_valid or not is_digit(id):
            log_invalid_error_message(self.log, 'Access control id')
            return
        kwargs = {'url': self.config.authorization_url + '/' + id}
        response = issue_request_refresh(self,
            request_method=requests.delete,
            params=get_request_kwargs(kwargs, self.config)
        )
        if not response:
            return
        print_raw_response(response)
        self.log.info('Access control entry ' + id + ' has been deleted')

    def _create_update_authorization(self, verb):
        pargs = self.app.pargs
        request_method = {
            'create': requests.post,
            'update': requests.put
        }.get(verb)
        operations = pargs.operations.split(',')
        request_kwargs = {
            'url': self.config.authorization_url,
            'json': {
                'resourceuri': pargs.resource_uri,
                'operations': operations,
                'principaluri': pargs.principal_uri,
                'access': pargs.access,
                'identityauthority': pargs.id_authority
            }
        }
        response = issue_request_refresh(self,
            request_method=request_method,
            params=get_request_kwargs(request_kwargs, self.config)
        )
        if not response:
            return
        print_raw_response(response)
        self.app.log.info('Authorization {} - {} for {} on {} complete'.format(
            pargs.operations,
            pargs.access,
            pargs.principal_uri,
            pargs.resource_uri
        ))
