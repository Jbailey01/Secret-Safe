import sys
import os
import requests
import json
from cement import ex
from secretssafe.controllers.base import SecretsSafeBaseController

from secretssafe.utils.cli_utils import (get_request_kwargs, get_from_pargs,
                                         issue_request_refresh, write_file_bytes, print_raw_response,
                                         try_has_value_from_pargs, load_file_bytes, file_exists)
from secretssafe.utils.secret_scope_utils import (try_is_secret, is_scope, get_secret,
                                                  parse_secret_crud_args, create_secret_with_bytes,
                                                  create_secret_with_generator, create_secret_with_file)
from secretssafe.utils.validation_utils import (is_null_or_whitespace, log_invalid_error_message,
                                                prompt_confirm)
from secretssafe.utils.json_utils import format_json_string, is_json_string

DESC = 'Manage secrets.'


class SecretController(SecretsSafeBaseController):

    class Meta:
        label = 'secret'
        stacked_on = 'base'
        stacked_type = 'nested'
        description = DESC
        help = ': ' + DESC

    @ex(hide=True)
    def _default(self):
        super()._display_help('secret')

    @ex(
        arguments=[
            (['URI'],
             {'help': ''': URI of the secret. URI must be in the format scope_path:secret_name.
                         For example, path/to/secret:secret_name.''',
              'action': 'store',
              'nargs': 1}),
            (['-f', '--file-path'],
             {'help': ': Path to the file to be stored.',
              'dest': 'file_path',
              'required': False}),
            (['-g', '--generator-name'],
             {'help': ': The name of the generator used to generate the value.',
              'dest': 'generator_name',
              'required': False})
            ],
        help=': Create a secret.')
    def create(self):
        self._create_update_secret('create')

    def _get_secrets_for_scope(self, url, directory):
        # if we are not in integrated mode we should try to create the directory we will write to
        if not self.config.integrated and not os.path.isdir(directory):
            try:
                os.mkdir(directory)
            except OSError:
                self.log.error('directory {} could not be created'.format(directory))
                return
        urls = self.get_secret_urls(url)

        # request failed
        if urls is None:
            return
        # request went through but no secrets found
        if len(urls) == 0:
            print('No secrets exist in this scope')
            return
        # raw output for all found secrets
        secret_output = []
        if self.config.integrated:
            directory = ''
        for secret_uri in urls:
            secret_name = secret_uri[(secret_uri.index(':') + 1):]
            write_path = '{}/{}'.format(directory, secret_name)
            self._get_secret(secret_uri, write_path)
 

    def get_secret_urls(self, url):

        def _parse_urls(secrets_json):
            if 'Secrets' not in secrets_json:
                return []
            return [secret['Uri'][8:] for secret in response_json['Secrets']]
        url = '{}/{}'.format(self.config.secret_url, url)
        response = issue_request_refresh(
            self,
            request_method=requests.get,
            params=get_request_kwargs({'url': url}, self.config)
        )

        if not response:
            return
        try:
            response_json = response.json()
        except json.decoder.JSONDecodeError:
            return
        # no pagination, just get secrets from current response
        if 'Paging' not in response_json:
            return _parse_urls(response_json)

        page_count = response_json['Paging']['PageCount']
        secret_urls = []
        page_num = 1
        # iterate over each page
        while page_num <= page_count:
            secret_urls += _parse_urls(response_json)
            # increment page and get the next set of results
            page_num += 1
            response = issue_request_refresh(
                self,
                request_method=requests.get,
                params=get_request_kwargs({'url': url, 'params' : {'page_number': page_num}},
                                          self.config)
            )
            # if we run into a problem return what we have so far
            if not response:
                return secret_urls
            try:
                response_json = response.json()
            except json.decoder.JSONDecodeError:
                return secret_urls
        return secret_urls

    def _get_secret(self, url, file_path):

        content = get_secret(self, url)
        if not content:
            return

        if file_path:
            write_file_bytes(file_path, content)
            return
        if not sys.stdout.isatty():
            sys.stdout.buffer.write(content)
            return
        try:
            data = content.decode()
            if is_json_string(data):
                data = format_json_string(data)
        except UnicodeDecodeError:
            data = content
        print(data)

    @ex(
        arguments=[
            (['URI'],
             {'help': ''': URI of the secret or scope. If a scope is provided the -d argument must have a value.''',
              'action': 'store',
              'nargs': 1}),
            (['-d', '--dir'],
             {'help': ': Destination directory, all secrets within a scope will be written here.',
              'dest': 'directory_path',
              'required': False})              
            ],
        help=': Return the value of the specified secret or secrets under a given scope.')
    def get(self):
        pargs = self.app.pargs
        directory_path = get_from_pargs(pargs, 'directory_path')
        uri = self.app.pargs.URI[0].lstrip('/')
        if is_null_or_whitespace(uri):
            log_invalid_error_message(self.log, 'Secret URI', '')
            return

        if is_scope(uri):
            if is_null_or_whitespace(directory_path) and not self.config.integrated:
                log_invalid_error_message(self.log, 'Arguments',
                                      '-d argument requires value if target uri is for a scope')
                return
            self._get_secrets_for_scope(uri, directory_path)
        else:
            if not is_null_or_whitespace(directory_path):
                log_invalid_error_message(self.log, 'Arguments', 
                                          '-d argument is invalid if target uri is for a secret')
                return
            self._get_secret(uri, None)

    @ex(
        arguments=[
            (['URI'],
             {'help': ''': URI of the secret. URI must be in the format scope_path:secret_name.
                         For example, path/to/secret:secret_name.''',
              'action': 'store',
              'nargs': 1}),
            (['-f', '--file-path'],
             {'help': ': Path to the file to be stored.',
              'dest': 'file_path',
              'required': False}),
            (['-g', '--generator-name'],
             {'help': ': The name of the generator used to generate the value.',
              'dest': 'generator_name',
              'required': False})
            ],
        help=': Update a secret.')
    def update(self):
        self._create_update_secret('update')

    @ex(
        arguments=[
            (['URI'],
             {'help': ''': URI of the secret. URI must be in the format scope_path:secret_name.
                         For example, path/to/secret:secret_name.''',
              'action': 'store',
              'nargs': 1})
            ],
        help=': Delete a secret.')
    def delete(self):
        pargs = self.app.pargs
        url, uri = parse_secret_crud_args(pargs, self.config.secret_url)
        is_valid, details = try_is_secret(uri, 'delete')
        if not is_valid:
            log_invalid_error_message(self.log, 'Secret URI', details)
            return
        if not prompt_confirm('Are you sure you want to delete secret ' + uri + '?'):
            self.log.info('Delete cancelled.')
            return
        response = issue_request_refresh(self,
            request_method=requests.delete,
            params=get_request_kwargs({'url': url}, self.config)
        )
        if not response:
            return
        print_raw_response(response)
        self.log.info('Secret at ' + uri + ' successfully deleted.')

    def _create_update_secret(self, verb):
        uri_has_value, uri = try_has_value_from_pargs(self.app.pargs, 'URI')
        if not uri_has_value:
            log_invalid_error_message(self.log, 'Secret URI')
            return
        uri = uri[0]
        is_valid, details = try_is_secret(uri, verb)
        if not is_valid:
            log_invalid_error_message(self.log, 'Secret URI', details)
            return

        file_path_has_value, file_path = try_has_value_from_pargs(self.app.pargs, 'file_path')
        if file_path_has_value:
            if not file_exists(file_path):
                log_invalid_error_message(self.log, 'File path')
                return
        generator_has_value, generator_name = try_has_value_from_pargs(self.app.pargs, 'generator_name')

        if generator_has_value:
            if is_null_or_whitespace(generator_name):
                log_invalid_error_message(self.log, 'Generator name')
                return
        secret_data = None
        if self.config.stdin_file:
            secret_data = self.config.stdin_file

       # we need at least one of these
        if not any([file_path, generator_name, secret_data]):
            log_invalid_error_message(self.log, 'Secret data')
            return

        # more than one input type is not valid
        all_inputs = [secret_input for secret_input in [file_path, generator_name, secret_data]
                      if secret_input]
        if len(all_inputs) > 1:
            user_friendly_input_names_map = {file_path: 'file path', generator_name: 'generator', secret_data: 'input stream'}
            provided_input_names = [user_friendly_input_names_map[input_name] for input_name in all_inputs]
            log_invalid_error_message(self.log, 'Secret data',
                                      'only one secret data input allowed, {} were provided'
                                      .format(','.join(provided_input_names)))
            return
 
        update_existing = verb == 'update'
        if file_path:
            response = create_secret_with_file(self, uri, file_path, update_existing)
        elif generator_name:
            response = create_secret_with_generator(self, uri, generator_name, update_existing)
        elif secret_data:
            response = create_secret_with_bytes(self, uri, secret_data, update_existing)

        if not response:
            return
        print_raw_response(response)
        if file_path:
            success_msg = ('Successfully encrypted and ' + verb + 'd secret found at ' + file_path
                           + ' to ' + uri)
        else:
            success_msg = 'Successfully encrypted and ' + verb + 'd secret ' + 'to ' + uri
        self.log.info(success_msg)
