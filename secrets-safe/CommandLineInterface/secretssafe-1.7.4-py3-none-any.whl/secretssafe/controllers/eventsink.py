import json
from http import HTTPStatus
import requests
from cement import ex
from secretssafe.controllers.base import SecretsSafeBaseController
from secretssafe.config import ALL
from secretssafe.utils.cli_utils import *
from secretssafe.utils.validation_utils import *

DESC = 'Manage event sinks.'


class EventSinkController(SecretsSafeBaseController):

    class Meta:
        label = 'event-sink'
        stacked_on = 'base'
        stacked_type = 'nested'
        description = DESC
        help = ': ' + DESC

    @ex(hide=True)
    def _default(self):
        super()._display_help('event-sink')

    @ex(
        arguments=[
            (['-f', '--file-path'],
             {'help': ': Path to the event sink configuration file.',
              'dest': 'file_path',
              'required': True})
            ],
        help=': Create an event sink.')
    def create(self):
        pargs = self.app.pargs
        is_valid, file_path = try_get_value_from_pargs(pargs, 'file_path')
        if not is_valid:
            log_invalid_error_message(self.log, 'Event Sink File')
            return
        data = read_file_contents(file_path)
        response = issue_request_refresh(self,
            request_method=requests.post,
            params=get_request_kwargs(
                kwargs={'url': self.config.event_sink_url, 'data': data},
                config=self.config,
                headers={'content-type': 'application/json'}
                )
            )
        if not response:
            return
        if response.status_code == HTTPStatus.CREATED:
            if print_raw_response(response):
                return
            self.log.info(json.dumps(response.json(), indent=4))

    @ex(
        arguments=[
            (['-n', '--name'],
             {'help': ''': The name of the event sink to display. If no name is specified, all
                         configured event sinks are listed.''',
              'dest': 'event_sink_name',
              'required': False}),
            ],
        help=': Return list of event sinks or the configuration of a specific event sink.')

    def get(self):
        response = issue_request_refresh(self,
            request_method=requests.get,
            params=get_request_kwargs(
                {'url': self.config.event_sink_url},
                self.config
                )
        )
        if not response or response.status_code != HTTPStatus.OK:
            return
        event_sinks = response.json()
        print(json.dumps(event_sinks, indent=4))

    @ex(
        arguments=[
            (['-f', '--file-path'],
             {'help': ': Path to the event sink configuration file.',
              'dest': 'file_path',
              'required': True}),
            (['-n', '--name'],
             {'help': ': The name of the event sink to be updated.',
              'dest': 'event_sink_name',
              'required': True})
            ],
        help=': Update an existing configuration.')

    def update(self):
        pargs = self.app.pargs
        is_valid, event_sink_name = try_get_value_from_pargs(pargs, 'event_sink_name')
        if not is_valid:
            log_invalid_error_message(self.log, 'Event Sink Name')
            return
        is_valid, file_path = try_get_value_from_pargs(pargs, 'file_path')
        if not is_valid:
            log_invalid_error_message(self.log, 'Event Sink File')
            return
        data = read_file_contents(file_path)
        response = issue_request_refresh(self,
            request_method=requests.put,
            params=get_request_kwargs(
                kwargs={'url': self.config.event_sink_url + '/' + event_sink_name, 'data': data},
                config=self.config,
                headers={'content-type': 'application/json'}
                )
            )
        if not response:
            return
        if response.status_code == HTTPStatus.OK:
            self.log.info('Event sink ' + event_sink_name + ' updated.')
            if print_raw_response(response):
                return
            if is_json_string(response.content.decode()):
                self.log.info(json.dumps(response.json(), indent=4))

    @ex(
        arguments=[
            (['-n', '--name'],
             {'help': ': The name of the event sink to be deleted.',
              'dest': 'event_sink_name',
              'required': True}),
            ],
        help=': Delete an event sink.')

    def delete(self):
        pargs = self.app.pargs
        is_valid, event_sink_name = try_get_value_from_pargs(pargs, 'event_sink_name')
        if not is_valid:
            log_invalid_error_message(self.log, 'Event Sink Name')
            return
        response = issue_request_refresh(self,
            request_method=requests.delete,
            params=get_request_kwargs(
                {'url': self.config.event_sink_url + '/' + event_sink_name},
                self.config
            )
        )
        if not response:
            return
        print_raw_response(response)
        self.log.info('Event sink ' + event_sink_name + ' has been deleted')
