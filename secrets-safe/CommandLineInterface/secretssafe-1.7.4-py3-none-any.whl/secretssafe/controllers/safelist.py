import json
from http import HTTPStatus
import requests
from cement import ex
from secretssafe.controllers.base import SecretsSafeBaseController
from secretssafe.utils.cli_utils import *
from secretssafe.utils.validation_utils import *
from secretssafe.utils.json_utils import *

DESC = 'Manage safelists.'


class SafelistController(SecretsSafeBaseController):

    class Meta:
        label = 'safelist'
        stacked_on = 'base'
        stacked_type = 'nested'
        description = DESC
        help = ': ' + DESC

    @ex(hide=True)
    def _default(self):
        super()._display_help('safelist')

    @ex(
        arguments=[
            (['-f', '--file-path'],
             {'help': ': Path to the file containing safelist data.',
              'dest': 'file_path',
              'required': True})
            ],
        help=': Create a safelist.')
    def create(self):
        is_valid, file_path = try_get_value_from_pargs(self.app.pargs, 'file_path')
        if not is_valid:
            log_invalid_error_message(self.log, 'Safelist file')
            return
        data = read_file_contents(file_path)
        response = issue_request_refresh(self,
            request_method=requests.post,
            params=get_request_kwargs(
                kwargs={'url': self.config.safelist_url, 'data': data},
                config=self.config,
                headers={'content-type': 'application/json'}
                )
            )
        if not response:
            return
        if response.status_code == HTTPStatus.CREATED:
            print(json.dumps(response.json(), indent=4, sort_keys=True))

    @ex(
        arguments=[
            (['-n', '--name'],
             {'help': ''': If a name is specified, only that safelist is returned and sorting and 
                         pagination options are ignored. If no name is specified, a list of safelists 
                         is returned with sorting and pagination options (if specified) applied.''',
              'dest': 'name',
              'required': False}),
            (['-v', '--verbose'],
             {'help': ''': Verbose output. Use the -v flag to get a full listing of safelist and
                         ip range attributes. Otherwise, a slim view of each safelist and ip range
                         is returned.''',
              'action': 'store_true'}),
            (['-d', '--depth'],
             {'help': ''': The maximum depth of the view to return. A value of 0 returns only the
                         element specified. A value of 1 returns the element specified and all
                         direct children. A value of 2 returns all children and grandchildren of
                         the element specified.''',
              'dest': 'depth',
              'required': False}),
            (['-ps', '--page-size'],
             {'help': ''': Specifies the maximum number of elements to return in the safelist listing. 
                         Value must be between 1 and 100. Note, child IP range listings will also 
                         be limited to this page size.''',
              'dest': 'page_size',
              'required': False}),
            (['-pn', '--page_number'],
             {'help': ''': Specifies the page number (1-based) of results to return.''',
              'dest': 'page_number',
              'required': False}),
            (['-sb', '--sort-by'],
             {'help': ''': Specifies the sort order for the safelist listing. This is defined
                         as a single field or comma delimeted list of fields with the sort order
                         (one of:ace|desc) specified in brackets after each and mentioned in single
                         quotes. For example: 'Name(desc)' OR 'Name(desc)','Url(asc)'.''',
              'dest': 'sort_by',
              'required': False})
            ],
        help=': List SafeLists.')
    def get(self):
        pargs = self.app.pargs
        has_value, safelist_name = try_has_value_from_pargs(pargs, 'name')
        if not has_value:
            url = self.config.safelist_url
        else:
            is_valid = not is_null_or_whitespace(safelist_name)
            if not is_valid:
                log_invalid_error_message(self.log, 'Safelist name')
                return
            url = self.config.safelist_url + '/' + safelist_name
        is_valid, model_data = try_get_filter_model_from_pargs(pargs)
        if not is_valid:
            log_invalid_error_message(self.log, model_data)
            return
        request_kwargs = {
            'url': url,
            'params': model_data
        }
        response = issue_request_refresh(self,
            request_method=requests.get,
            params=get_request_kwargs(request_kwargs, self.config)
        )
        if not response:
            return
        if response.status_code == HTTPStatus.OK:
            print(json.dumps(response.json(), indent=4, sort_keys=True))

    @ex(
        arguments=[
            (['-n', '--name'],
             {'help': ': Name of the safelist to be updated.',
              'dest': 'name',
              'required': True}),
            (['-f', '--file-path'],
             {'help': ': Path to the file containing safelist data',
              'dest': 'file_path',
              'required': True})
            ],
        help=': Update a safelist.')
    def update(self):
        pargs = self.app.pargs
        is_valid, name = try_get_value_from_pargs(pargs, 'name')
        if not is_valid:
            log_invalid_error_message(self.log, 'Safelist name')
            return
        is_valid, file_path = try_get_value_from_pargs(self.app.pargs, 'file_path')
        if not is_valid:
            log_invalid_error_message(self.log, 'Safelist file')
            return
        data = read_file_contents(file_path)
        response = issue_request_refresh(self,
            request_method=requests.put,
            params=get_request_kwargs(
                kwargs={'url': self.config.safelist_url + '/' + name, 'data': data},
                config=self.config,
                headers={'content-type': 'application/json'}
                )
            )
        if not response:
            return
        print_raw_response(response)
        self.log.info('SafeList ' + name + ' has been updated.')

    @ex(
        arguments=[
            (['-n', '--name'],
             {'help': ': Name of the safelist to be deleted.',
              'dest': 'name',
              'required': True}),
            ],
        help=': Delete a safeList.')
    def delete(self):
        is_valid, name = try_get_value_from_pargs(self.app.pargs, 'name')
        if not is_valid:
            log_invalid_error_message(self.log, 'Safelist name')
            return
        response = issue_request_refresh(self,
            request_method=requests.delete,
            params=get_request_kwargs({'url': self.config.safelist_url + '/' + name}, self.config)
        )
        if not response:
            return
        print_raw_response(response)
        self.log.info('SafeList ' + name + ' has been deleted.')
