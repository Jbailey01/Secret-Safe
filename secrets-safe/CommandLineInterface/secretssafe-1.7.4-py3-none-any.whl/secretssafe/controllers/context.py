from tabulate import tabulate
from cement import ex
from secretssafe.controllers.base import SecretsSafeBaseController
from secretssafe.config import (DEFAULT_API_VERSION, CONTEXT_HEADERS, TABLE_FORMAT,
                                SECRETSSAFE_HOST, SECRETSSAFE_PORT, SECRETSSAFE_VERIFY_CA, SECRETSSAFE_CA_DATA)
from secretssafe.utils.cli_utils import *
from secretssafe.utils.context_utils import *
from secretssafe.utils.json_utils import *
from secretssafe.utils.validation_utils import *

DESC = 'Manage contexts.'


class ContextController(SecretsSafeBaseController):

    class Meta:
        label = 'context'
        stacked_on = 'base'
        stacked_type = 'nested'
        description = DESC
        help = ': ' + DESC

    @ex(hide=True)
    def _default(self):
        super()._display_help('context')

    @ex(
        arguments=[
            (['-n', '--name'],
             {'help': ': Name of new context.',
              'dest': 'name',
              'required': False}),
            (['-a', '--address'],
             {'help': ': Hostname or IP address of Secrets Safe instance.',
              'dest': 'address',
              'required': False}),
            (['-p', '--port'],
             {'help': ': Port of Secrets Safe.',
              'dest': 'port',
              'required': False}),
            (['-s', '--ssl-configuration'],
             {'help': ': SSL CA verification configuration.',
              'dest': 'ssl_configuration',
              'required': False}),
            (['-v', '--api-version'],
             {'help': ': API version of Secrets Safe instance.',
              'dest': 'api_version',
              'required': False}),
            (['-c', '--ca-data'],
             {'help': ': Base64 encoded certificate authority bundle',
              'dest': 'ca_data',
              'required': False})
            ],
        help=': Create a Secrets Safe context.')
    def create(self):
        pargs = self.app.pargs
        contexts = load_contexts(self.config)

        # check existence of context by name
        is_valid, name = try_get_value_from_pargs_or_prompt(pargs, 'name',
            'Context name:')
        if not is_valid:
            log_invalid_error_message(self.log, 'Context name')
            return
        if get_dict_from_iter('name', name, contexts):
            self.log.error('Context ' + name + ' already exists.')
            return

        # prompt for details if not provided as arguments
        is_valid, address = try_get_value_from_pargs_or_prompt(pargs, 'address',
                                                     'Instance hostname/IP:')
        if not is_valid:
            log_invalid_error_message(self.log, 'Instance hostname/IP')
            return

        is_valid, port = try_get_value_from_pargs_or_prompt(pargs, 'port',
                                                  'Instance port:')
        if not is_valid or not is_digit(port):
            log_invalid_error_message(self.log, 'Instance port')
            return

        is_valid, ssl_configuration = get_from_pargs_or_prompt(validate_string, pargs, 'ssl_configuration',
                                                               'SSL CA verification configuration (enter to default to true):', default='True')
        if not is_valid:
            log_invalid_error_message(self.log, 'SSL CA verification')
            return

        is_valid, api_version = get_from_pargs_or_prompt(validate_string, pargs, 'api_version',
                                                         'API version (enter to default to v1):', default=DEFAULT_API_VERSION)
        if not is_valid:
            log_invalid_error_message(self.log, 'API version')
            return

        is_valid, ca_data = get_from_pargs_or_prompt(validate_base64_string, pargs, 'ca_data',
                                                    'Ca bundle data (enter to default to none):', default='')
        if not is_valid:
            log_invalid_error_message(self.log, 'CA Data')
            return

        # update the contexts accordingly
        new_context = {
            'name': name,
            'api_version': api_version,
            SECRETSSAFE_HOST: address,
            SECRETSSAFE_PORT: port,
            SECRETSSAFE_VERIFY_CA: ssl_configuration,
            SECRETSSAFE_CA_DATA: ca_data
        }
        persist_context(self.config, new_context)
        self.log.info('Context ' + name + ' successfully created.')


    @ex(
        arguments=[
            (['-n', '--name'],
             {'help': ': Context name. If not specified, all contexts are listed.',
              'dest': 'name',
              'required': False}),
            ],
        help=': Return list of configured Secrets Safe contexts.')
    def get(self):
        pargs = self.app.pargs
        has_value, name = try_has_value_from_pargs(pargs, 'name')
        displayed_contexts = []
        contexts = load_contexts(self.config)
        if has_value:
            if is_null_or_whitespace(name):
                log_invalid_error_message(self.log, 'Context name')
                return
            context = get_dict_from_iter('name', name, contexts)
            if not context:
                self.log.error('Context not found')
                return
            displayed_contexts.append(context)
        else:
            displayed_contexts.extend(contexts)
        table = [build_context_table(self.config, context) for context in displayed_contexts]
        alphabetical = sorted(table, key=lambda x: x[0])
        print(tabulate(alphabetical, CONTEXT_HEADERS, tablefmt=TABLE_FORMAT))

    @ex(
        arguments=[
            (['-n', '--name'],
             {'help': ': Name of context to update.',
              'dest': 'name',
              'required': False}),
            (['-a', '--address'],
             {'help': ': Hostname or IP address of Secrets Safe instance.',
              'dest': 'address',
              'required': False}),
            (['-p', '--port'],
             {'help': ': Port of Secrets Safe.',
              'dest': 'port',
              'required': False}),
            (['-s', '--ssl-configuration'],
             {'help': ': SSL CA verification configuration.',
              'dest': 'ssl_configuration',
              'required': False}),
            (['-v', '--api-version'],
             {'help': ': API version of Secrets Safe instance.',
              'dest': 'api_version',
              'required': False}),
            (['-c', '--ca-data'],
             {'help': ': Base64 encoded certificate authority bundle',
              'dest': 'ca_data',
              'required': False})              
            ],
        help=': Update attributes of a given Secrets Safe context.')
    def update(self):
        pargs = self.app.pargs
        contexts = load_contexts(self.config)

        is_valid, name = try_get_value_from_pargs_or_prompt(pargs, 'name', 'Context name:')
        if not is_valid:
            log_invalid_error_message(self.log, 'Context name')
            return
        context = get_dict_from_iter('name', name, contexts)
        if not context:
            self.log.error('Context ' + name + ' does not exist.')
            return

        is_valid, address = try_get_value_from_pargs_or_prompt(pargs, 'address', 'Instance hostname/IP:')
        if not is_valid:
            log_invalid_error_message(self.log, 'Instance hostname/IP')
            return

        is_valid, port = try_get_value_from_pargs_or_prompt(pargs, 'port', 'Instance port:')
        if not is_valid or not is_digit(port) or is_null_or_whitespace(port):
            log_invalid_error_message(self.log, 'Instance port')
            return

        is_valid, ssl_configuration = get_from_pargs_or_prompt(validate_string, pargs, 'ssl_configuration',
                                                               'SSL CA verification configuration (enter to default to true):', default='True')
        if not is_valid:
            log_invalid_error_message(self.log, 'SSL CA verification')
            return

        is_valid, api_version = get_from_pargs_or_prompt(validate_string, pargs, 'api_version',
                                                         'API version (enter to default to v1):', default=DEFAULT_API_VERSION)
        if not is_valid:
            log_invalid_error_message(self.log, 'API version')
            return

        is_valid, ca_data = get_from_pargs_or_prompt(validate_base64_string, pargs, 'ca_data',
                                                    'Ca bundle data (enter to default to none):', default='')
        if not is_valid:
            log_invalid_error_message(self.log, 'CA Data')
            return

        for key, value in [
                (SECRETSSAFE_HOST, address),
                (SECRETSSAFE_PORT, port),
                (SECRETSSAFE_VERIFY_CA, ssl_configuration),
                ('api_version', api_version)
            ]:
            if not value:
                continue
            context[key] = value
        persist_context(self.config, context)
        self.log.info('Context ' + name + ' updated.')


    @ex(
        arguments=[
            (['-n', '--name'],
             {'help': ': Name of context to delete.',
              'dest': 'name',
              'required': False}),
            ],
        help=': Delete a Secrets Safe context.')
    def delete(self):
        is_valid, name = try_get_value_from_pargs_or_prompt(self.app.pargs, 'name', 'Context name:')
        if not is_valid:
            log_invalid_error_message(self.log, 'Context name')
            return
        contexts = load_contexts(self.config)
        context = get_dict_from_iter('name', name, contexts)
        if not context:
            self.log.error('Context ' + name + ' does not exist.')
            return
        delete_context(self.config, name)
        self.log.info('Context ' + name + ' deleted.')


    @ex(
        arguments=[
            (['-n', '--name'],
             {'help': ': Name of context to set as current.',
              'dest': 'name',
              'required': False}),
            ],
        help=': Set the current context.')
    def set_current(self):
        is_valid, name = try_get_value_from_pargs_or_prompt(self.app.pargs, 'name', 'Context name:')
        if not is_valid:
            log_invalid_error_message(self.log, 'Context name')
            return
        contexts = load_contexts(self.config)
        context = get_dict_from_iter('name', name, contexts)
        if not context:
            self.log.error('Context ' + name + ' does not exist.')
            return
        self.config.current_context = context
        persist_context(self.config, context)
        self.log.info('Context ' + name + ' set as current.')
