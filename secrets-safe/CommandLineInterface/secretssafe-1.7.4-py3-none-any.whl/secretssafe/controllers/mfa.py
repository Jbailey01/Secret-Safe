import json
from http import HTTPStatus
import urllib.parse
import requests
from cement import ex
import pyotp
import qrcode
from secretssafe.controllers.base import SecretsSafeBaseController
from secretssafe.utils.cli_utils import *
from secretssafe.utils.mfa_utils import generate_totp_secret_and_qr_code
from secretssafe.utils.validation_utils import *

DESC = 'Manage multi-factor authentication configurations'


class MfaController(SecretsSafeBaseController):

    class Meta:
        label = 'mfa'
        stacked_on = 'base'
        stacked_type = 'nested'
        description = DESC
        help = ': ' + DESC

    @ex(hide=True)
    def _default(self):
        super()._display_help('mfa')

    @ex(
        arguments=[
            (['-f', '--file-path'],
             {'help': ': Path to the provider configuration file.',
              'dest': 'file_path',
              'required': True})
            ],
        help=': Configure a new multi-factor authentication provider.')
    def create(self):
        is_valid, file_path = try_get_value_from_pargs(self.app.pargs, 'file_path')
        if not is_valid:
            log_invalid_error_message(self.log, 'MFA File')
            return
        data = read_file_contents(file_path)
        response = issue_request_refresh(self,
            request_method=requests.post,
            params=get_request_kwargs(
                kwargs={'url': self.config.mfa_url, 'data': data},
                config=self.config,
                headers={'content-type': 'application/json'}
                )
            )
        if not response:
            return
        if response.status_code == HTTPStatus.CREATED:
            self.log.info('Multi-Factor authentication provider created:')
            if print_raw_response(response):
                return
            self.log.info(json.dumps(response.json(), indent=4))

    @ex(help=''': Return list of multi-factor authentication configurations.''')
    def get(self):
        response = issue_request_refresh(self,
            request_method=requests.get,
            params=get_request_kwargs(
                {'url': self.config.mfa_url},
                self.config
                )
        )
        if not response or response.status_code != HTTPStatus.OK:
            return
        providers = response.json()
        print(json.dumps(providers, indent=4))

    @ex(
        arguments=[
            (['-f', '--file-path'],
             {'help': ': Path to the provider configuration file.',
              'dest': 'file_path',
              'required': True}),
            (['-n', '--name'],
             {'help': ': The name of the multi-factor authentication configuration to be updated.',
              'dest': 'mfa_name',
              'required': True})
            ],
        help=': Update an existing configuration.')
    def update(self):
        pargs = self.app.pargs
        is_valid, mfa_config_name = try_get_value_from_pargs(
            self.app.pargs, 'mfa_name')
        if not is_valid:
            log_invalid_error_message(self.log, 'MFA Name')
            return
        is_valid, file_path = try_get_value_from_pargs(pargs, 'file_path')
        if not is_valid:
            log_invalid_error_message(self.log, 'MFA File')
            return
        data = read_file_contents(file_path)
        response = issue_request_refresh(self,
            request_method=requests.put,
            params=get_request_kwargs(
                kwargs={'url': self.config.mfa_url + '/' + mfa_config_name, 'data': data},
                config=self.config,
                headers={'content-type': 'application/json'}
                )
            )
        if not response:
            return
        if response.status_code == HTTPStatus.OK:
            self.log.info('Configuration  ' + mfa_config_name + ' updated.')
            if print_raw_response(response):
                return
            if is_json_string(response.content.decode()):
                self.log.info(json.dumps(response.json(), indent=4))

    @ex(
        arguments=[
            (['-n', '--name'],
             {'help': ': Name of the multi-factor authentication configuration to be deleted.',
              'dest': 'provider_name',
              'required': True}),
            ],
        help=': Delete a multi-factor authentication configuration.')
    def delete(self):
        is_valid, provider_name = try_get_value_from_pargs(
            self.app.pargs, 'provider_name')
        if not is_valid:
            log_invalid_error_message(self.log, 'MFA Name')
            return
        response = issue_request_refresh(self,
            request_method=requests.delete,
            params=get_request_kwargs(
                kwargs={
                    'url': self.config.mfa_url + '/' + provider_name
                    },
                config=self.config
            )
        )
        if not response:
            return
        print_raw_response(response)
        self.log.info('Multi-factor authentication configuration ' + provider_name + ' has been deleted')

    @ex(
        arguments=[
            (['-p', '--principal'],
             {'help': ': Principal URI.',
              'dest': 'principal_uri',
              'required': True}),
            (['-m', '--mfa-id'],
             {'help': ': The id on the mfa-provider side. If this is omitted a totp secret key will be generated and assigned',
              'dest': 'mfa_id',
              'required': False}),
            (['-c', '--mfa-config'],
             {'help': ': The name of the multi-factor authentication configuration to use.',
              'dest': 'mfa_config',
              'required': True})
            ],
        help=': Assign multi-factor authentication to a principal.')
    def assign_principal(self):
        generated_totp = None
        qr_code = None
        is_valid, principal_uri = try_get_value_from_pargs(
            self.app.pargs, 'principal_uri')
        if not is_valid:
            log_invalid_error_message(self.log, 'Principal URI')
            return

        is_valid, mfa_config = try_get_value_from_pargs(
            self.app.pargs, 'mfa_config')
        if not is_valid:
            log_invalid_error_message(self.log, 'MFA Config')
            return

        is_valid, mfa_id = try_get_value_from_pargs(
            self.app.pargs, 'mfa_id')
        if not is_valid:
            generated_totp, qr_code = generate_totp_secret_and_qr_code(principal_uri)
            mfa_id = generated_totp

        data = json.dumps({'mfaId': mfa_id, 'mfaConfiguration': mfa_config})
        response = issue_request_refresh(self,
            request_method=requests.post,
            params=get_request_kwargs(
                kwargs={'url': self.config.principal_url + '/' + urllib.parse.quote(principal_uri, '') + '/multi_factor',
                        'data': data}, config=self.config,
                headers={'content-type': 'application/json'}
            )
        )
        if not response:
            self.log.error('Multi-factor authentication configuration assignment failed')
            return
        if generated_totp:
            print(f'totp enabled for principal {principal_uri}')
            print(f'scan the below qr code with a supported device or use the secret key {generated_totp}')
            qr_code.print_ascii()
    @ex(
        arguments=[
            (['-p', '--principal'],
             {'help': ': Principal URI.',
              'dest': 'principal_uri',
              'required': True})
            ],
        help=': Remove multi-factor authentication from a principal.')
    def remove_principal(self):
        is_valid, principal_uri = try_get_value_from_pargs(
            self.app.pargs, 'principal_uri')
        if not is_valid:
            log_invalid_error_message(self.log, 'Principal URI')
            return
        response = issue_request_refresh(self,
            request_method=requests.delete,
            params=get_request_kwargs(
                kwargs={'url': self.config.principal_url + '/' + urllib.parse.quote(principal_uri, '') + '/multi_factor'},
                config=self.config,
                headers={'content-type': 'application/json'}
                )
            )
        if not response:
            self.log.error('Multi-factor authentication configuration removal failed')
            return
