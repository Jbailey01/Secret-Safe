# pylint: disable=no-self-use
import subprocess
from cement import ex
from secretssafe.controllers.base import SecretsSafeBaseController

DESC = 'Manage shell autocompletion.'


class CompletionController(SecretsSafeBaseController):

    class Meta:
        label = 'completion'
        stacked_on = 'base'
        stacked_type = 'nested'
        description = DESC
        help = ': ' + DESC

    @ex(hide=True)
    def _default(self):
        super()._display_help('completion')

    @ex(help=': Dump bash autocomplete configuration.')
    def bash(self):
        print(subprocess.check_output(['register-python-argcomplete', 'ssrun']).decode())
