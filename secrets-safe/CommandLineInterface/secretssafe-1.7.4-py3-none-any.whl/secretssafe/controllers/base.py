# pylint: disable=protected-access,attribute-defined-outside-init
from argparse import _StoreAction, _StoreConstAction
from cement import Controller
from cement.utils.shell import Prompt
from secretssafe.utils.argparse_overrides import SubcommandHelpFormatter, action_call, const_call
from secretssafe.utils.cli_utils import configure_runtime_attributes, check_for_auth_token
from secretssafe.config import (MAX_PASSWORD_CONFIRM_ATTEMPTS, NO_AUTH_CMDS, NO_CONFIG_ARGS,
                                ALL_CMDS)


# monkeypatch cement framework to custom values
_StoreAction.__call__, _StoreConstAction.__call__ = action_call, const_call
Prompt.Meta.max_attempts = MAX_PASSWORD_CONFIRM_ATTEMPTS


class SecretsSafeBaseController(Controller):

    class Meta:
        argument_formatter = SubcommandHelpFormatter

    def _setup(self, app):
        self.log = app.log
        self.config = app.ss_config
        super()._setup(app)

    def _is_runnable(self, argv):
        # this is not a command that requres context configuration
        if argv.intersection(NO_CONFIG_ARGS) or argv == {'-v'}:
            return True
        # this command does require context configuration, typical flow
        if argv.intersection(ALL_CMDS):
            if not configure_runtime_attributes(self.log, self.config):
                return False
            if argv.isdisjoint(NO_AUTH_CMDS):
                if not check_for_auth_token(self.log, self.config):
                    return False
        return True

    def _dispatch(self):
        argv = set(self.app.argv)
        if argv:
            if not self._is_runnable(argv):
                return
        super()._dispatch()

    def _display_help(self, controller):
        self.app.args.parse_args([controller, '--help'])
