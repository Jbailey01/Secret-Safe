import json
from http import HTTPStatus
import requests
from cement import ex
from secretssafe.controllers.base import SecretsSafeBaseController
from secretssafe.utils.cli_utils import *
from secretssafe.utils.validation_utils import *
from secretssafe.const.k8s_identity_provider import K8_IDENTITY_PROVIDER_CONFIG, K8_IDENTITY_PROVIDER_NAME

DESC = 'Manage identity providers.'


class IdentityController(SecretsSafeBaseController):

    class Meta:
        label = 'identity'
        stacked_on = 'base'
        stacked_type = 'nested'
        description = DESC
        help = ': ' + DESC

    @ex(hide=True)
    def _default(self):
        super()._display_help('identity')

    @ex(
        arguments=[
            (['-f', '--file-path'],
             {'help': ': Path to the provider configuration file.',
              'dest': 'file_path',
              'required': False}),
            (['-n', '--name'],
             {'help': (': Name of pre-configured provider. Currently kubernetes is the only supported pre-configured provider and will configure the cluster hosting secrets-safe as an identity provide'),
              'dest': 'provider_name',
              'required': False})              
            ],
        help=': Configure a new identity provider.')
    def create(self):
        pargs = self.app.pargs
        valid_provider_name, provider_name = try_get_value_from_pargs(pargs, 'provider_name')
        valid_file_path, file_path = try_get_value_from_pargs(pargs, 'file_path')
        if not valid_file_path and not valid_provider_name:
            self.log.error('Must provider either -n or -f argument')
            return
        if valid_provider_name and valid_file_path:
            self.log.error('Both -n and -f arguments are not supported. Please choose either -n or -f argument')
            return

        # we are using a pre-configured identity provider
        if valid_provider_name:
            if provider_name.lower() != K8_IDENTITY_PROVIDER_NAME.lower():
                log_invalid_error_message(self.log, 'Provider name',
                                          '{} is not a supported pre-configured provider'.format(provider_name))
                return
            data = K8_IDENTITY_PROVIDER_CONFIG
        else:
            is_valid, file_path = try_get_value_from_pargs(pargs, 'file_path')
            if not is_valid:
                log_invalid_error_message(self.log, 'Identity Provider File')
                return
            data = read_file_contents(file_path)

        response = issue_request_refresh(self,
            request_method=requests.post,
            params=get_request_kwargs(
                kwargs={'url': self.config.principal_url, 'data': data},
                config=self.config,
                headers={'content-type': 'application/json'}
                )
            )
        if not response:
            return

        if response.status_code == HTTPStatus.CREATED:
            self.log.info('Identity provider created:')
            if print_raw_response(response):
                return
            self.log.info(json.dumps(response.json(), indent=4))

    @ex(
        arguments=[
            (['-n', '--name'],
             {'help': ''': Name of the identity provider to display. If not specified, all
                         identity providers are listed.''',
              'dest': 'provider_name',
              'required': False}),
            ],
        help=''': Return list of identity providers or the configuration of a specific identify
                provider.''')
    def get(self):
        response = issue_request_refresh(self,
            request_method=requests.get,
            params=get_request_kwargs(
                {'url': self.config.principal_url + '/_config'},
                self.config
                )
        )
        if not response or response.status_code != HTTPStatus.OK:
            return
        providers = response.json()
        print(json.dumps(providers, indent=4))

    @ex(
        arguments=[
            (['-f', '--file-path'],
             {'help': ': Path to the provider configuration file.',
              'dest': 'file_path',
              'required': True}),
            (['-n', '--name'],
             {'help': ': Name of the identity provider to be updated.',
              'dest': 'provider_name',
              'required': True})
            ],
        help=': Update an existing identity provider configuration.')

    def update(self):
        pargs = self.app.pargs
        is_valid, provider_name = try_get_value_from_pargs(pargs, 'provider_name')
        if not is_valid:
            log_invalid_error_message(self.log, 'Identity Provider Name')
            return
        is_valid, file_path = try_get_value_from_pargs(pargs, 'file_path')
        if not is_valid:
            log_invalid_error_message(self.log, 'Identity Provider File')
            return
        data = read_file_contents(file_path)
        response = issue_request_refresh(self,
            request_method=requests.put,
            params=get_request_kwargs(
                kwargs={'url': self.config.principal_url + '/' + provider_name,
                        'data': data},
                config=self.config,
                headers={'content-type': 'application/json'}
                )
            )
        if not response:
            return
        if response.status_code == HTTPStatus.OK:
            self.log.info('Identity provider ' + provider_name + ' updated.')
            if print_raw_response(response):
                return
            if is_json_string(response.json()):
                self.log.info(json.dumps(response.json(), indent=4))

    @ex(
        arguments=[
            (['-n', '--name'],
             {'help': ': Name of the identity provider to be deleted.',
              'dest': 'provider_name',
              'required': True}),
            ],
        help=': Delete an identity provider configuration.')

    def delete(self):
        pargs = self.app.pargs
        is_valid, provider_name = try_get_value_from_pargs(pargs, 'provider_name')
        if not is_valid:
            log_invalid_error_message(self.log, 'Identity Provider Name')
            return
        response = issue_request_refresh(self,
            request_method=requests.delete,
            params=get_request_kwargs(
                kwargs={
                    'url': self.config.principal_url + '/' + provider_name
                    },
                config=self.config
            )
        )
        if not response:
            return
        print_raw_response(response)
        self.log.info('Identity provider ' + provider_name + ' has been deleted')
