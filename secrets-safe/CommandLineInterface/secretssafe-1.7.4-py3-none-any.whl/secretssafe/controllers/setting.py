import sys
import requests
from http import HTTPStatus
from cement import ex
from secretssafe.controllers.base import SecretsSafeBaseController
from secretssafe.config import ALL
from secretssafe.utils.cli_utils import *
from secretssafe.utils.validation_utils import *
from secretssafe.utils.json_utils import *

DESC = 'Manage global user settings.'


class SettingController(SecretsSafeBaseController):

    class Meta:
        label = 'setting'
        stacked_on = 'base'
        stacked_type = 'nested'
        description = (DESC +
        '\n\nSetting resource_uri: system/settings/' +
        '\n\nAvaliable settings:' +
        '\n\tServer:Limits:MaxRequestBodySize - default 1048576 bytes' +
        '\n\tJwt:AccessTokenTimeToLiveSeconds - default 3600 seconds' +
        '\n\tJwt:RefreshTokenTimeToLiveSeconds - default 2592000 seconds')
        help = ': ' + DESC

    @ex(hide=True)
    def _default(self):
        super()._display_help('setting')

    @ex(
        arguments=[
            (['-n', '--name'],
             {'help': ': Setting name.',
              'dest': 'setting_name',
              'required': True}),
            (['-v', '--value'],
             {'help': ': Value of setting.',
              'dest': 'setting_value',
              'required': True})
            ],
        help=': Create a setting.')
    def create(self):
        self._create_update_setting('create')

    @ex(
        arguments=[
            (['-n', '--name'],
             {'help': ': Setting name.',
              'dest': 'setting_name',
              'required': False})
            ],
        help=': Return the value of the specified setting or all settings.')
    def get(self):
        has_value, setting_name = try_has_value_from_pargs(self.app.pargs, 'setting_name')
        if has_value:
            if is_null_or_whitespace(setting_name):
                log_invalid_error_message(self.log, 'Setting name')
                return
        request_kwargs={'url': self.config.setting_url}
        if setting_name:
            params = {}
            params['settingname'] = setting_name
            request_kwargs={'url': self.config.setting_url, 'params': params}
        response = issue_request_refresh(self,
            request_method=requests.get,
            params=get_request_kwargs(request_kwargs, self.config)
        )
        if not response:
            return
        if response.status_code == HTTPStatus.OK:
            if setting_name:
                print(response.text)
            else:
                print(format_json_string(response.text))

    @ex(
        arguments=[
            (['-n', '--name'],
             {'help': ': Setting name.',
              'dest': 'setting_name',
              'required': True}),
            (['-v', '--value'],
             {'help': ': Value of setting.',
              'dest': 'setting_value',
              'required': True})
            ],
        help=': Update a setting.')
    def update(self):
        self._create_update_setting('update')

    @ex(
        arguments=[
            (['-n', '--name'],
             {'help': ': Setting name.',
              'dest': 'setting_name',
              'required': True})
            ],
        help=': Delete a setting.')
    def delete(self):
        is_valid, setting_name = try_get_value_from_pargs(
            self.app.pargs, 'setting_name')
        if not is_valid:
            log_invalid_error_message(self.log, 'Setting name')
            return
        params = {}
        params['settingname'] = setting_name
        response = issue_request_refresh(self,
            request_method=requests.delete,
            params=get_request_kwargs(
                {'url': self.config.setting_url, 'params': params}, 
                self.config)
        )
        if not response:
            return
        if response.status_code == HTTPStatus.OK:
            print_raw_response(response)
            self.log.info('Setting: ' + setting_name + ' successfully deleted.')

    def _create_update_setting(self, verb):
        is_valid, setting_name = try_get_value_from_pargs(
            self.app.pargs, 'setting_name')
        if not is_valid:
            log_invalid_error_message(self.log, 'Setting name')
            return
        is_valid, setting_value = try_get_value_from_pargs(
            self.app.pargs, 'setting_value')
        if not is_valid:
            log_invalid_error_message(self.log, 'Setting value')
            return
        params = {}
        params['settingname'] = setting_name
        params['value'] = setting_value
        response = issue_request_refresh(self,
            request_method={'create': requests.post, 'update': requests.put}.get(verb),
            params=get_request_kwargs(
                kwargs={'url': self.config.setting_url, 'params': params},
                config=self.config,
                headers={'content-type': 'application/json'}
                )
            )
        if not response:
            return
        print_raw_response(response)
        if response.status_code == HTTPStatus.OK:
            self.log.info('Successfully saved setting: ' + setting_name)

