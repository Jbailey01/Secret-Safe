import requests
from cement import ex
from secretssafe.controllers.base import SecretsSafeBaseController
from secretssafe.utils.cli_utils import *
from secretssafe.utils.secret_scope_utils import *
from secretssafe.utils.validation_utils import *

DESC = 'Manage scopes.'


class ScopeController(SecretsSafeBaseController):

    class Meta:
        label = 'scope'
        stacked_on = 'base'
        stacked_type = 'nested'
        description = DESC
        help = ': ' + DESC

    @ex(hide=True)
    def _default(self):
        super()._display_help('scope')

    @ex(
        arguments=[
            (['URI'],
             {'help': ': URI of the scope.',
              'action': 'store',
              'nargs': 1}),
            ],
        help=': Create a scope.')
    def create(self):
        url, uri = parse_secret_crud_args(self.app.pargs, self.config.secret_url)
        is_valid, details = try_is_scope(uri, 'create')
        if not is_valid:
            log_invalid_error_message(self.log, 'Scope URI', details)
            return
        response = issue_request_refresh(self,
            request_method=requests.post,
            params=get_request_kwargs({'url': url}, self.config)
        )
        if not response:
            return
        print_raw_response(response)
        self.log.info('Scope ' + uri + ' created successfully')

    @ex(
        arguments=[
            (['uri'],
             {'help': ': URI of the scope targeted for retrieval.',
              'nargs': '?',
              'default': None}),
            (['-v', '--verbose'],
             {'help': ''': Verbose output. Use the -v flag to get a full listing of secret and
                         scope attributes. Otherwise, a slim view of each secret and scope is
                         returned.''',
              'action': 'store_true'}),
            (['-d', '--depth'],
             {'help': ''': The maximum depth of the view to return. A value of 0 returns only the
                         element specified in the URI. A value of 1 returns the element specified
                         in the URI and all direct children. A value of 2 returns all children and
                         grandchildren of the element specified in the URI... etc.''',
              'dest': 'depth',
              'required': False}),
            (['-ps', '--page-size'],
             {'help': ''': Specifies the number of records to return for the direct children of the 
                         element specified in the URI. Values must be between 1 and 100. Note, all 
                         grandchildren of the element specified in the URI will also be limited to 
                         this page size.''',
              'dest': 'page_size',
              'required': False}),
            (['-pn', '--page_number'],
             {'help': ''': Specifies the page number (1-based) of results to return.''',
              'dest': 'page_number',
              'required': False}),
            (['-sb', '--sort-by'],
             {'help': ''': Specifies the sort order for the scope listing. This is defined
                         as a single field or comma delimeted list of fields with the sort order
                         (one of:ace|desc) specified in brackets after each and mentioned in single
                         quotes. For example: 'Name(desc)' OR 'Name(desc)','Url(asc)'.''',
              'dest': 'sort_by',
              'required': False})
            ],
        help=': Return list of the items at the specified scope.')
    def get(self):
        pargs = self.app.pargs
        url = self.config.secret_url
        uri = get_from_pargs(pargs, 'uri')
        if uri:
            is_valid, details = try_is_scope(uri, 'get')
            if not is_valid:
                log_invalid_error_message(self.log, 'Scope URI', details)
                return
            url = self.config.secret_url + '/' + uri
        is_valid, model_data = try_get_filter_model_from_pargs(pargs)
        if not is_valid:
            log_invalid_error_message(self.log, model_data)
            return
        response = issue_request_refresh(self,
            request_method=requests.get,
            params=get_request_kwargs({'url': url, 'params': model_data}, self.config)
        )
        if not response:
            return
        pprint_json(response.json())

    @ex(
        arguments=[
            (['URI'],
             {'help': ': URI of the scope.',
              'action': 'store',
              'nargs': 1}),
            ],
        help=': Delete the specified scope and all its children.')
    def delete(self):
        url, uri = parse_secret_crud_args(self.app.pargs,
                                             self.config.secret_url)
        is_valid, details = try_is_scope(uri, 'delete')
        if not is_valid:
            log_invalid_error_message(self.log, 'Scope URI', details)
            return
        if not prompt_confirm((
                'Are you sure you want to delete scope at ' + uri + '? This will not only delete '
                'the scope but also all child scopes and secrets.'
        )):
            self.log.info('Delete cancelled.')
            return
        response = issue_request_refresh(self,
            request_method=requests.delete,
            params=get_request_kwargs({'url': url}, self.config)
        )
        if not response:
            return
        print_raw_response(response)
        self.log.info('Scope ' + uri + ' deleted successfully')
