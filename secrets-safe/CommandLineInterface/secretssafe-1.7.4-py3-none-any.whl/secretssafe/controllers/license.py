import json
from http import HTTPStatus
import requests
from cement import ex
from secretssafe.controllers.base import SecretsSafeBaseController
from secretssafe.utils.cli_utils import *
from secretssafe.utils.validation_utils import *

DESC = 'Manage license information.'


class LicenseController(SecretsSafeBaseController):

    class Meta:
        label = 'license'
        stacked_on = 'base'
        stacked_type = 'nested'
        description = DESC
        help = ': ' + DESC

    @ex(hide=True)
    def _default(self):
        super()._display_help('license')

    @ex(
        arguments=[
            (['-f', '--force'],
             {'help': ''': Used to indicate that the system should request an update of the
                         licensing information from the licensing server.''',
              'action': 'store_true'}),
        ],
        help=': Retrieve Secrets Safe license information.')
    def get(self):
        force = self.app.pargs.force
        params = {}
        if force:
            params['force'] = force
        kwargs = {
            'url': self.config.license_url,
            'params': params
        }
        response = issue_request_refresh(self,
            request_method=requests.get,
            params=get_request_kwargs(kwargs, self.config)
        )
        if not response:
            return
        if response.status_code == HTTPStatus.OK:
            self.log.info('Secrets Safe has successfully retrieved license information.')
        # Display licensing data
        print(json.dumps(response.json(), indent=4))

    @ex(
        arguments=[
            (['-s', '--serial-number'],
             {'help': ': The serial number that you have received for this product.',
              'dest': 'serial_number',
              'required': True}),
            (['-l', '--license-key'],
             {'help': ''': Used for offline activation. Using your serial number, from a machine
                         connected to the internet, go to https://licensing.beyondtrust.com to
                         generate your license key.''',
              'dest': 'license_key',
              'required': False}),
            ],
        help=': License Secrets Safe.')
    def update(self):
        pargs = self.app.pargs
        is_valid, serial_number = try_get_value_from_pargs(
            pargs, 'serial_number')
        if not is_valid:
            log_invalid_error_message(self.log, 'License Number')
            return
        license_key = get_from_pargs(pargs, 'license_key')
        response = issue_request_refresh(self,
            request_method=requests.put,
            params=get_request_kwargs(
                kwargs={
                    'url': self.config.license_url,
                    'json': {
                        'serialNumber': serial_number,
                        'offlineLicenseKey': license_key or ''
                    }
                },
                config=self.config
            )
        )
        if not response:
            return
        if response.status_code == HTTPStatus.OK:
            self.log.info('Secrets Safe has been successfully licensed.')
        # Display licensing data
        print(json.dumps(response.json(), indent=4))

    @ex(help=': Delete Secrets Safe license.')
    def delete(self):
        kwargs = {'url': self.config.license_url}
        response = issue_request_refresh(self,
            request_method=requests.delete,
            params=get_request_kwargs(kwargs, self.config)
        )
        if not response:
            return
        if response.status_code == HTTPStatus.OK:
            self.log.info('Secrets Safe has successfully deleted license information.')
        # Display licensing data
        print(json.dumps(response.json(), indent=4))
