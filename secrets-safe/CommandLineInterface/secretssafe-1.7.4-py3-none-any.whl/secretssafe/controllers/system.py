import sys
import json
from tabulate import tabulate
from http import HTTPStatus
import requests
from cement import ex
from secretssafe import version
from secretssafe.controllers.base import SecretsSafeBaseController
from secretssafe.config import STATUS_HEADERS, TABLE_FORMAT, OUTPUT_JSON, OUTPUT_TABLE
from secretssafe.utils.cli_utils import *
from secretssafe.utils.validation_utils import *
from secretssafe.utils.json_utils import *

class SystemController(SecretsSafeBaseController):

    class Meta:
        label = 'base'
        description = (
            ASCII_BANNER +
            'Secrets Safe Command Line Client. Manage principals, secrets, authorization, and all '
            'other entities along with Secrets Safe at a system level.'
            )
        arguments = [
            (
                ['-v', '--version'],
                {'help': ': Display ssrun version.',
                 'action': 'store_true',
                 'dest': 'version'}
            ),
        ]

    @ex(hide=True)
    def _default(self):
        if get_from_pargs(self.app.pargs, 'version'):
            print(version.__version__)
        else:
            self.app.args.parse_args(['--help'])

    @ex(help=': Initialize Secrets Safe.')
    def init(self):
        self.log.info('Initializing Secrets Safe...')
        is_valid, prompt_result = prompt_password(True)
        if not is_valid:
            self.log.error(prompt_result if prompt_result else 'Password is invalid.')
            return
        response = issue_request(
            request_method=requests.post,
            params={
                'url': self.config.initialization_url,
                'json': {'rootpassword': prompt_result}
            }
        )
        if not response:
            return
        master_key = format_json_string(response.content.decode())
        if not sys.stdout.isatty():
            sys.stdout.buffer.write(master_key.encode())
        else:
            print('\n' + master_key)

    @ex(
        arguments=[
            (['-f', '--file-path'],
             {'help': ': Path to master key file.',
              'dest': 'path_to_key'}),
            (['-s', '--serial-number'],
             {'help': ''': The serial number that you have received for this product. If no serial
                         number is provided, upon a successful unseal, this product will only be
                         available for 30 days.''',
              'dest': 'serial_number',
              'required': False}),
            (['-l', '--license-key'],
             {'help': ''': Used for offline activation.  Using your serial number, from a machine
                         connected to the internet, go to https://licensing.beyondtrust.com to
                         generate your license key.''',
              'dest': 'license_key',
              'required': False}),
            ],
        help=': Unseal Secrets Safe.')
    def unseal(self):
        pargs = self.app.pargs
        master_key = None
        master_key_file = pargs.path_to_key
        if self.config.stdin_file:
            bytes_io = self.config.stdin_file
            byte_str = bytes_io.read()
            master_key = byte_str.decode('UTF-8')
        if master_key_file:
            master_key = read_file_contents(master_key_file)
        if not master_key:
            log_invalid_error_message(self.log, 'Master Key')
            return
        if not is_json_string(master_key):
            self.log.error('Could not parse master key file as json.')
            return
        serial_number = pargs.serial_number or ''
        self.log.info('Unsealing Secrets Safe...')
        license_args = {
            'serialNumber': serial_number,
            'offlineLicenseKey': pargs.license_key or ''
        }
        unseal_args = {
            'JsonWebKey': json.loads(master_key, strict=False),
            'license': license_args
        }
        response = issue_request(
            request_method=requests.post,
            params=get_request_kwargs(
                kwargs={'url': self.config.unseal_url, 'data': json.dumps(unseal_args)},
                config=self.config,
                headers={'content-type': 'application/json'}
            )
        )
        if not response:
            return
        if print_raw_response(response):
            return
        if response.status_code == HTTPStatus.OK:
            self.log.info('Secrets Safe has been successfully unsealed.')
        if serial_number:
            # Display licensing data
            print(json.dumps(response.json(), indent=4, sort_keys=False))

    @ex(help=': Seal Secrets Safe.')
    def seal(self):
        response = issue_request_refresh(self,
            request_method=requests.put,
            params=get_request_kwargs({'url': self.config.seal_url}, self.config)
        )
        if not response:
            return
        if print_raw_response(response):
            return
        if response.status_code == HTTPStatus.OK:
            self.app.log.info('Secrets Safe has been successfully sealed.')

    @ex(
        arguments=[
            (['-u', '--username'],
             {'help': ': User name for user authentication.',
              'dest': 'username',
              'required': False}),
            (['-p', '--password'],
             {'help': ': Password for user authentication.',
              'dest': 'password',
              'required': False}),
            (['-k', '--api-key'],
             {'help': ': Api Key for application authentication.',
              'dest': 'api_key',
              'required': False}),
            (['-t', '--token'],
             {'help': ': JWT for ServiceAccount authentication.',
              'dest': 'jwt',
              'required': False}),
            (['-a', '--application-name'],
             {'help': ': Application name for application authentication.',
              'dest': 'application_name',
              'required': False}),
            (['-i', '--identity-provider'],
             {'help': ''': Identity provider for authentication. Defaults to internal if not
                         specified''',
              'dest': 'identity_provider',
              'required': False}),
            (['-m', '--mfa-passcode'],
             {'help': ''': Passcode for multi-factor authentication if applicable''',
              'dest': 'mfa_passcode',
              'required': False}),
            ],
        help=': Log in using username/password or application name and api key.')
    def login(self):
        pargs = self.app.pargs
        self.logout()
        if pargs.jwt:
            is_valid, jwt = try_get_value_from_pargs_or_prompt(
                pargs, 'jwt', 'Token:')
            if not is_valid:
                self.log.error('Token is invalid.')
                return
            id_provider = get_from_pargs(pargs, 'identity_provider') or 'kubernetes'
            auth_token, refresh_token, _ = authenticate_user(
            self.log, self.config, "default", jwt, id_provider, None)
            return
        if any([pargs.api_key, pargs.application_name]):
            is_valid, app_name = try_get_value_from_pargs_or_prompt(
                pargs, 'application_name', 'Application name:')
            if not is_valid:
                self.log.error('Application name is invalid.')
                return
            is_valid, api_key = try_get_value_from_pargs_or_prompt(
                pargs, 'api_key', 'API key:')
            if not is_valid:
                self.log.error('API key is invalid.')
                return
            authenticate_application(self.log, self.config, api_key, app_name)
            return
        is_valid, username = try_get_value_from_pargs_or_prompt(
            pargs, 'username', 'Username:')
        if not is_valid:
            self.log.error('Username is invalid.')
            return
        is_valid, password = try_get_value_from_pargs_or_prompt_password(
            pargs, 'password', False)
        if not is_valid:
            self.log.error('Password is invalid.')
            return
        id_provider = get_from_pargs(pargs, 'identity_provider') or 'internal'
        mfa_passcode = get_from_pargs(pargs, 'mfa_passcode')
        auth_token, refresh_token, _ = authenticate_user(
            self.log, self.config, username, password, id_provider, mfa_passcode)

    @ex(help=': Log out.')
    def logout(self):
        clear_auth_token(self.config)
        clear_refresh_token(self.config)
        self.log.info('Logout successful')

    @ex(help=': Get current logged in users name.')
    def whoami(self):
        current_authenticated_principal = get_logged_in_principal(self.log, self.config)
        if not current_authenticated_principal:
            return
        print(current_authenticated_principal.name)

    @ex(arguments=[
            (['-o', '--output'],
             {'help': ': Displays status output either in table or json. Table is the default format',
              'dest': 'output',
              'required': False,
              'default': 'table',
              'choices': ['json', 'table']})
    ],
        help=': Get status.')
    def status(self):
        response = issue_request_refresh(self,
            request_method=requests.get,
            params=get_request_kwargs({'url': self.config.status_url}, self.config)
        )
        if not response:
            return
        pargs = self.app.pargs
        if pargs.output == OUTPUT_TABLE:
            response_json = response.json()
            service_statuses = response_json.get('ServiceStatuses')
            filtered_fields_output = ['ServiceType', 'ServiceInstance', 'Timestamp', 'State', 'IsUnsealed']
            filtered_json = filter_json_fields(filtered_fields_output, service_statuses)
            for i in range (0, len(filtered_json)):
                version_obj = service_statuses[i].get('Version')
                version_list = list(version_obj.values())
                version_metadata = version_list.pop()
                format_version_string = '.'.join(str(version) for version in version_list) + '-' + version_metadata
                filtered_json[i].insert(2, format_version_string)
            alphabetical = sorted(filtered_json, key=lambda x: x[0])
            print('ProductVersion: ' + str(response_json.get('ProductVersion')) + '\n')
            print('ServiceStatuses: ' + '\n')
            print(tabulate(alphabetical, STATUS_HEADERS, tablefmt=TABLE_FORMAT))
        elif pargs.output == OUTPUT_JSON:
            pprint_json(response.json())
