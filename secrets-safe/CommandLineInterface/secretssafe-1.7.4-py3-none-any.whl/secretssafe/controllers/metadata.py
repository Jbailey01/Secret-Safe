from json import JSONDecodeError
import requests
from cement import ex
from secretssafe.controllers.base import SecretsSafeBaseController
from secretssafe.utils.cli_utils import (issue_request_refresh, get_request_kwargs,
                                         print_raw_response)
from secretssafe.utils.json_utils import format_json_string
from secretssafe.utils.secret_scope_utils import parse_metadata_crud_args
from secretssafe.utils.validation_utils import *

DESC = 'Manage metadata.'


class MetadataController(SecretsSafeBaseController):

    class Meta:
        label = 'metadata'
        stacked_on = 'base'
        stacked_type = 'nested'
        description = DESC
        help = ': ' + DESC

    @ex(hide=True)
    def _default(self):
        super()._display_help('metadata')

    @ex(
        arguments=[
            (['URI'],
             {'help': ''': The URI of the scope or secret the metadata item is associated with. To
                         reference the resource, pass its full URI. For example, to referense a scope, 
                         use /secret/path/to/scope. 
                         To reference a secret, use secret/path/to/secret:secret_name.''',
              'action': 'store',
              'nargs': 1}),
            (['-n', '--name'],
             {'help': ': Name of metadata item.',
              'dest': 'metadata_name',
              'required': True}),
            (['-v', '--value'],
             {'help': ': Value of metadata item.',
              'dest': 'metadata_value',
              'required': True})
            ],
        help=': Create a user metadata item associated with a scope or secret.')
    def create(self):
        url, _, metadata_name, metadata_value = parse_metadata_crud_args(self.app.pargs,
                                                                         self.config.api_root_url)
        response = issue_request_refresh(self,
            request_method=requests.post,
            params=get_request_kwargs(
                kwargs={
                    'url': url,
                    'json': {
                        'value': metadata_value,
                        'name': metadata_name
                    }
                },
                config=self.config
            )
        )
        if not response:
            return
        print_raw_response(response)
        self.log.info('Metadata item ' + metadata_name + ' created successfully')

    @ex(
        arguments=[
            (['URI'],
             {'help': ''': The URI of the scope or secret the metadata item is
                         associated with. To reference the resource, use the full URI. 
                         For example, secret/path/to/secrets. To reference
                         a secret, use secret/path/to/secret:secret_name.''',
              'action': 'store',
              'nargs': 1}),
            (['-n', '--name'],
             {'help': ''': Name of metadata item. If no name is specified, all
                         metadata items are listed for a scope or secret.''',
              'dest': 'metadata_name',
              'required': False})
            ],
        help=': Get user metadata item(s) associated with a scope or secret.')
    def get(self):
        url, uri, metadata_name, _ = parse_metadata_crud_args(self.app.pargs,
                                                              self.config.api_root_url)
        response = issue_request_refresh(self,
            request_method=requests.get,
            params=get_request_kwargs(
                kwargs={
                    'url': url,
                    'params': {'userMetadataName': metadata_name}
                },
                config=self.config
            )
        )
        if not response:
            return
        try:
            metadata = format_json_string(response.content.decode())
            if not metadata:
                return
            print(metadata)
        except (JSONDecodeError, ValueError):
            if metadata_name:
                error_log = 'No user metadata found for ' + metadata_name + ' at URI ' + uri
            else:
                error_log = 'No user metadata found at URI ' + uri
            self.log.error(error_log)

    @ex(
        arguments=[
            (['URI'],
             {'help': ''': The URI of the scope or secret the metadata item is associated with. To
                         reference the resource, use the full URI. For example, to reference a scope, 
                         use secret/path/to/secrets.
                         To reference a secret, use secret/path/to/secret:secret_name. ''',
              'action': 'store',
              'nargs': 1}),
            (['-n', '--name'],
             {'help': ': Name of metadata item.',
              'dest': 'metadata_name',
              'required': True}),
            (['-v', '--value'],
             {'help': ': Value of metadata item.',
              'dest': 'metadata_value',
              'required': True})
            ],
        help=': Update a user metadata item associated with a scope or secret.')
    def update(self):
        url, _, metadata_name, metadata_value = parse_metadata_crud_args(self.app.pargs,
                                                                         self.config.api_root_url)
        response = issue_request_refresh(self,
            request_method=requests.put,
            params=get_request_kwargs(
                kwargs={
                    'url': url,
                    'json': {
                        'value': metadata_value,
                        'name': metadata_name
                    }
                },
                config=self.config
            )
        )
        if not response:
            return
        print_raw_response(response)
        self.log.info('Metadata item ' + metadata_name + ' updated successfully')

    @ex(
        arguments=[
            (['URI'],
             {'help': ''': The URI of the scope or secret the metadata item is associated with. To
                         reference the resource, use the full URI. For example, to reference a scope, 
                         use secret/path/to/secrets.
                         To reference a secret, use secret/path/to/secret:secret_name.''',
              'action': 'store',
              'nargs': 1}),
            (['-n', '--name'],
             {'help': ': Name of metadata item.',
              'dest': 'metadata_name',
              'required': True})
            ],
        help=': Delete a user metadata item associated with a scope or secret.')
    def delete(self):
        url, _, metadata_name, _ = parse_metadata_crud_args(self.app.pargs,
                                                            self.config.api_root_url)
        response = issue_request_refresh(self,
            request_method=requests.delete,
            params=get_request_kwargs(
                kwargs={
                    'url': url,
                    'json': {
                        'name': metadata_name
                    }
                },
                config=self.config
            )
        )
        if not response:
            return
        print_raw_response(response)
        self.log.info('Metadata item ' + metadata_name + ' deleted successfully')
