from http import HTTPStatus
import requests
from cement import ex
from secretssafe.controllers.base import SecretsSafeBaseController
from secretssafe.utils.cli_utils import (issue_request_refresh, get_request_kwargs, file_exists,
                                         read_file_contents, try_get_filter_model_from_pargs)
from secretssafe.utils.validation_utils import (try_get_value_from_pargs, is_null_or_whitespace,
                                                log_invalid_error_message, pprint_json, try_has_value_from_pargs)
from secretssafe.utils.dynamic_utils import create_dynamic_account

DESC = 'Manage dynamic accounts.'
class DynamicController(SecretsSafeBaseController):
    class Meta:
        label = 'dynamic'
        stacked_on = 'base'
        stacked_type = 'nested'
        description = DESC
        help = ': ' + DESC

    @ex(hide=True)
    def _default(self):
        super()._display_help('dynamic')

# region Dynamic Account Provider Configuration
class Provider(SecretsSafeBaseController):
    class Meta:
        label = 'provider'
        stacked_on = 'dynamic'
        stacked_type = 'nested'
        description = 'dynamic account providers'
        help = ': Manage Dynamic Account Provider Configuration'

    @ex(
        arguments=[
            (['-f', '--file-path'],
             {'help': ': Path to the dynamic account provider configuration file.',
              'dest': 'file_path',
              'required': True}),
        ],
        help=': Create a new dynamic account provider.')


    def create(self):
        pargs = self.app.pargs
        valid_file_path, file_path = try_get_value_from_pargs(pargs, 'file_path')
        if not valid_file_path:
            self.log.error('Must provide -f argument')
            return
        is_valid, file_path = try_get_value_from_pargs(pargs, 'file_path')
        if not is_valid:
            log_invalid_error_message(self.log, 'Dynamic Account Provider File')
            return
        data = read_file_contents(file_path)
        response = issue_request_refresh(self,
            request_method=requests.post,
            params=get_request_kwargs(
                kwargs={'url': self.config.dynamic_url, 'data': data},
                config=self.config,
                headers={'content-type': 'application/json'}
                )
            )
        if not response or response.status_code != HTTPStatus.CREATED:
            return
        pprint_json(response.json())


    @ex(
        arguments=[
            (['-p', '--provider-name'],
             {'help': ': Name of the dynamic provider for this account definition.',
              'dest': 'dynamic_provider_name',
              'required': True}),
            (['-f', '--file-path'],
             {'help': ': Path to the dynamic account definition file.',
              'dest': 'file_path',
              'required': True}),
            ],
        help=': Update a dynamic account providers configuration.')

    def update(self):
        pargs = self.app.pargs
        valid_dynamic_provider_name, dynamic_provider_name = try_get_value_from_pargs(pargs, 'dynamic_provider_name')
        valid_file_path, file_path = try_get_value_from_pargs(pargs, 'file_path')
        if not valid_dynamic_provider_name and not valid_file_path:
            self.log.error('Must provide both -p and -f arguments')
            return
        is_valid, dynamic_provider_name = try_get_value_from_pargs(pargs, 'dynamic_provider_name')
        is_valid = not is_null_or_whitespace(dynamic_provider_name)
        if not is_valid:
            log_invalid_error_message(self.log, 'Dynamic Provider Name')
            return
        dynamic_account_provider_url = self.config.dynamic_url + '/' + dynamic_provider_name

        is_valid, file_path = try_get_value_from_pargs(pargs, 'file_path')
        is_valid = not is_null_or_whitespace(file_path)
        if not is_valid:
            log_invalid_error_message(self.log, 'Dynamic Account Provider File')
            return
        data = read_file_contents(file_path)
        response = issue_request_refresh(self,
            request_method=requests.put,
            params=get_request_kwargs(
                kwargs={'url': dynamic_account_provider_url, 'data': data},
                config=self.config,
                headers={'content-type': 'application/json'}
                )
            )
        if not response or response.status_code != HTTPStatus.OK:
            return
        pprint_json(response.json())


    @ex(
        arguments=[
            (['-p', '--provider-name'],
             {'help': ': Name of the dynamic provider',
              'dest': 'dynamic_provider_name',
              'required': False}),
            (['-v', '--verbose'],
             {'help': ''': Verbose output. Use the -v flag to get a full listing of dynamic provider 
                         attributes. Otherwise, a slim view of dynamic provider is returned.''',
              'action': 'store_true'}),
            (['-d', '--depth'],
             {'help': ''': The maximum depth of the view to return. A value of 0 returns only the
                         element specified. A value of 1 returns the element specified and all
                         direct children. A value of 2 returns all children and grandchildren of
                         the element specified.''',
              'dest': 'depth',
              'required': False}),
            (['-ps', '--page-size'],
             {'help': ''': Specifies the maximum number of elements to return in the dynamic provider listing. 
                         Value must be between 1 and 100. Note, all dynamic/provider 
                         listings will also be limited to this page size.''',
              'dest': 'page_size',
              'required': False}),
            (['-pn', '--page_number'],
             {'help': ''': Specifies the page number (1-based) of results to return.''',
              'dest': 'page_number',
              'required': False}),
            (['-sb', '--sort-by'],
             {'help': ''': Specifies the sort order for the dynamic provider listing. This is defined
                         as a single field or comma delimeted list of fields with the sort order
                         (one of:ace|desc) specified in brackets after each and mentioned in single
                         quotes. For example: 'Name(desc)' OR 'Name(desc)','Url(asc)'.''',
              'dest': 'sort_by',
              'required': False})
            ],
        help=''': List the named dynamic account provider''')

    def get(self):
        pargs = self.app.pargs
        has_value, dynamic_provider_name = try_has_value_from_pargs(pargs, 'dynamic_provider_name')
        if not has_value:
            uri = self.config.dynamic_url
            is_valid, model_data = try_get_filter_model_from_pargs(pargs)
            if not is_valid:
                log_invalid_error_message(self.log, model_data)
                return
        else:
            is_valid = not is_null_or_whitespace(dynamic_provider_name)
            if not is_valid:
                log_invalid_error_message(self.log, 'Dynamic Provider Name')
                return
            uri = self.config.dynamic_url + '/' + dynamic_provider_name
            is_valid, model_data = try_get_filter_model_from_pargs(pargs)
            if not is_valid:
                log_invalid_error_message(self.log, model_data)
                return
        response = issue_request_refresh(self,
            request_method=requests.get,
            params=get_request_kwargs(
                kwargs={'url': uri, 'params': model_data},
                config=self.config,
            )
        )
        if not response or response.status_code != HTTPStatus.OK:
            return
        pprint_json(response.json())


    @ex(
        arguments=[
            (['-p', '--provider-name'],
             {'help': ': Name of the dynamic provider',
              'dest': 'dynamic_provider_name',
              'required': True}),
            (['-rm', '--purge-local-resources'],
             {'help': ''': Set to specify that account data should be removed
               from DSS even if the deletion cannot be synchronized with the 
               remote provider.''',
              'action': 'store_true'})
            ],
        help=''': Delete dynamic account provider''')

    def delete(self):
        pargs = self.app.pargs
        is_valid, dynamic_provider_name = try_has_value_from_pargs(pargs, 'dynamic_provider_name')
        is_valid = not is_null_or_whitespace(dynamic_provider_name)
        if not is_valid:
            log_invalid_error_message(self.log, 'Dynamic Provider Name')
            return
        query_args = {}
        purge_local_resources = self.app.pargs.purge_local_resources
        if purge_local_resources:
            query_args['purge_local_resources'] = purge_local_resources
        uri = self.config.dynamic_url + '/' + dynamic_provider_name
        response = issue_request_refresh(self,
            request_method=requests.delete,
            params=get_request_kwargs(
                kwargs={'url': uri,
                        'params': query_args},
                config=self.config,
            )
        )
        if not response or response.status_code != HTTPStatus.OK:
            return
# endregion


#region Dynamic Account Definition
class AccountDefinition(SecretsSafeBaseController):
    class Meta:
        label = 'account-definition'
        stacked_on = 'dynamic'
        stacked_type = 'nested'
        description = 'dynamic account definitions'
        help = ': Manage Dynamic Account Definition'

    @ex(
        arguments=[
            (['-p', '--provider-name'],
             {'help': ': Name of the dynamic provider for this account definition.',
              'dest': 'dynamic_provider_name',
              'required': True}),
            (['-f', '--file-path'],
             {'help': ': Path to the dynamic account definition file.',
              'dest': 'file_path',
              'required': True}),
        ],
        help=': Create a new dynamic account definition in the provider.')

    def create(self):
        pargs = self.app.pargs
        valid_dynamic_provider_name, dynamic_provider_name = try_get_value_from_pargs(pargs, 'dynamic_provider_name')
        valid_file_path, file_path = try_get_value_from_pargs(pargs, 'file_path')
        if not valid_file_path and not valid_dynamic_provider_name:
            self.log.error('Must provide both -p and -f arguments')
            return
        is_valid, dynamic_provider_name = try_get_value_from_pargs(pargs, 'dynamic_provider_name')
        is_valid = not is_null_or_whitespace(dynamic_provider_name)
        if not is_valid:
            log_invalid_error_message(self.log, 'Dynamic Provider Name')
            return
        dynamic_account_definition_url = self.config.dynamic_url + '/' + dynamic_provider_name

        is_valid, file_path = try_get_value_from_pargs(pargs, 'file_path')
        if not is_valid:
            log_invalid_error_message(self.log, 'Dynamic Account Definition File')
            return
        data = read_file_contents(file_path)
        response = issue_request_refresh(self,
            request_method=requests.post,
            params=get_request_kwargs(
                kwargs={'url': dynamic_account_definition_url, 'data': data},
                config=self.config,
                headers={'content-type': 'application/json'}
                )
            )

        if not response or response.status_code != HTTPStatus.CREATED:
            return
        pprint_json(response.json())


    @ex(
        arguments=[
            (['-a', '--account-definition'],
             {'help': ': Name of the target dynamic account definition for update.',
              'dest': 'dynamic_account_definition',
              'required': True}),
            (['-p', '--provider-name'],
             {'help': ': Name of the dynamic provider for this account definition.',
              'dest': 'dynamic_provider_name',
              'required': True}),
            (['-f', '--file-path'],
             {'help': ': Path to the dynamic account definition file.',
              'dest': 'file_path',
              'required': True}),
        ],
        help=': Update a dynamic account definition')

    def update(self):
        pargs = self.app.pargs
        valid_file_path, file_path = try_get_value_from_pargs(pargs, 'file_path')
        valid_dynamic_provider_name, dynamic_provider_name = try_get_value_from_pargs(pargs, 'dynamic_provider_name')
        valid_account_definition, dynamic_account_definition = try_get_value_from_pargs(pargs, 'dynamic_account_definition')
        if not valid_file_path and not valid_dynamic_provider_name and not valid_account_definition:
            self.log.error('Must provide -p, -a and -f arguments')
            return

        is_valid, dynamic_provider_name = try_get_value_from_pargs(pargs, 'dynamic_provider_name')
        is_valid = not is_null_or_whitespace(dynamic_provider_name)
        if not is_valid:
            log_invalid_error_message(self.log, 'Dynamic Provider Name')
            return
        dynamic_provider_name_url = self.config.dynamic_url + '/' + dynamic_provider_name
        is_valid, dynamic_account_definition = try_get_value_from_pargs(pargs, 'dynamic_account_definition')
        is_valid = not is_null_or_whitespace(dynamic_account_definition)
        if not is_valid:
            log_invalid_error_message(self.log, 'Dynamic Account Definition')
            return
        update_dynamic_account_definition_url = dynamic_provider_name_url + '/' + dynamic_account_definition

        is_valid, file_path = try_get_value_from_pargs(pargs, 'file_path')
        is_valid = not is_null_or_whitespace(file_path)
        if not is_valid:
            log_invalid_error_message(self.log, 'Dynamic Account Definition File')
            return
        data = read_file_contents(file_path)
        response = issue_request_refresh(self,
            request_method=requests.put,
            params=get_request_kwargs(
                kwargs={'url': update_dynamic_account_definition_url, 'data': data},
                config=self.config,
                headers={'content-type': 'application/json'}
                )
            )
        if not response or response.status_code != HTTPStatus.OK:
            return
        pprint_json(response.json())


    @ex(
        arguments=[
            (['-p', '--provider-name'],
             {'help': ': Name of the dynamic provider',
              'dest': 'dynamic_provider_name',
              'required': True}),
            (['-a', '--account-definition'],
             {'help': ': Name of the target dynamic account definition.',
              'dest': 'dynamic_account_definition',
              'required': False}),
            (['-v', '--verbose'],
             {'help': ''': Verbose output. Use the -v flag to get a full listing of dynamic account definition 
                         attributes. Otherwise, a slim view of each dynamic account definition is returned.''',
              'action': 'store_true'}),
            (['-d', '--depth'],
             {'help': ''': The maximum depth of the view to return. A value of 0 returns only the
                         element specified in the URI. A value of 1 returns the element specified
                         in the URI and all direct children. A value of 2 returns all children and
                         grandchildren of the element specified in the URI... etc.''',
              'dest': 'depth',
              'required': False}),
            (['-ps', '--page-size'],
             {'help': ''': Specifies the maximum number of elements to return in the dynamic account-definition listing. 
                         Value must be between 1 and 100. Note, all dynamic/provider/account-definition membership 
                         listings will also be limited to this page size.''',
              'dest': 'page_size',
              'required': False}),
            (['-pn', '--page_number'],
             {'help': ''': Specifies the page number (1-based) of results to return.''',
              'dest': 'page_number',
              'required': False}),
            (['-sb', '--sort-by'],
             {'help': ''': Specifies the sort order for the dynamic account definition listing. This is defined
                         as a single field or comma delimeted list of fields with the sort order
                         (one of:ace|desc) specified in brackets after each and mentioned in single
                         quotes. For example: 'Name(desc)' OR 'Name(desc)','Url(asc)'.''',
              'dest': 'sort_by',
              'required': False})
            ],
        help=''': List the named dynamic account-definition''')

    def get(self):
        pargs = self.app.pargs
        valid_dynamic_provider_name, dynamic_provider_name = try_get_value_from_pargs(pargs, 'dynamic_provider_name')        
        if not valid_dynamic_provider_name:
            self.log.error('Must provide -p argument')
            return
        else:
            is_valid = not is_null_or_whitespace(dynamic_provider_name)
            if not is_valid:
                log_invalid_error_message(self.log, 'Dynamic Provider Name')
                return
            dynamic_provider_uri = self.config.dynamic_url + '/' + dynamic_provider_name
        has_value, dynamic_account_definition = try_has_value_from_pargs(pargs, 'dynamic_account_definition')
        if not has_value:
            uri = dynamic_provider_uri
        else:
            is_valid = not is_null_or_whitespace(dynamic_account_definition)
            if not is_valid:
                log_invalid_error_message(self.log, 'Dynamic Account Definition')
                return
            uri = dynamic_provider_uri + '/' + dynamic_account_definition
        is_valid, model_data = try_get_filter_model_from_pargs(pargs)
        if not is_valid:
            log_invalid_error_message(self.log, model_data)
            return
        response = issue_request_refresh(self,
            request_method=requests.get,
            params=get_request_kwargs(
                kwargs={'url': uri, 'params': model_data},
                config=self.config,
            )
        )
        if not response or response.status_code != HTTPStatus.OK:
            return
        pprint_json(response.json())


    @ex(
        arguments=[
            (['-p', '--provider-name'],
             {'help': ': Name of the dynamic provider',
              'dest': 'dynamic_provider_name',
              'required': True}),
            (['-a', '--account-definition'],
             {'help': ': Name of the target dynamic account definition.',
              'dest': 'dynamic_account_definition',
              'required': True}),
            (['-rm', '--purge-local-resources'],
             {'help': ''': Set to specify that account data should be removed
               from DSS even if the deletion cannot be synchronized with the 
               remote provider.''',
              'action': 'store_true'})
            ],
        help=''': Delete dynamic account definition under a specific provider''')

    def delete(self):
        pargs = self.app.pargs
        valid_dynamic_provider_name, dynamic_provider_name = try_get_value_from_pargs(pargs, 'dynamic_provider_name')
        valid_account_definition, dynamic_account_definition = try_get_value_from_pargs(pargs, 'dynamic_account_definition')
        if not valid_dynamic_provider_name and not valid_account_definition:
            self.log.error('Must provide -p and -a arguments')
            return
        else: 
            is_valid, dynamic_provider_name = try_get_value_from_pargs(pargs, 'dynamic_provider_name')
            is_valid = not is_null_or_whitespace(dynamic_provider_name)
            if not is_valid:
                log_invalid_error_message(self.log, 'Dynamic Provider Name')
                return
            dynamic_provider_uri = self.config.dynamic_url + '/' + dynamic_provider_name
        is_valid, dynamic_account_definition = try_get_value_from_pargs(pargs, 'dynamic_account_definition')
        is_valid = not is_null_or_whitespace(dynamic_account_definition)
        if not is_valid:
            log_invalid_error_message(self.log, 'Dynamic Account Definition')
            return

        query_args = {}
        purge_local_resources = self.app.pargs.purge_local_resources
        if purge_local_resources:
            query_args['purge_local_resources'] = purge_local_resources

        uri = dynamic_provider_uri + '/' + dynamic_account_definition
        response = issue_request_refresh(self,
            request_method=requests.delete,
            params=get_request_kwargs(
                kwargs={'url': uri,
                        'params': query_args},
                config=self.config,
            )
        )
        if not response or response.status_code != HTTPStatus.OK:
            return
# endregion


#region Dynamic Account
class Account(SecretsSafeBaseController):
    class Meta:
        label = 'account'
        stacked_on = 'dynamic'
        stacked_type = 'nested'
        description = 'dynamic account'
        help = ': Manage Dynamic Account'

    @ex(
        arguments=[
            (['-p', '--provider-name'],
             {'help': ': Name of the dynamic provider for this account.',
              'dest': 'dynamic_provider_name',
              'required': True}),
            (['-a', '--account-definition'],
             {'help': ': Name of the target dynamic account definition.',
              'dest': 'dynamic_account_definition',
              'required': True}),
            (['-f', '--file-name'],
             {'help': ': Specify input file with account name for dynamic account creation. If input file is not provided, account name will be auto-generated. ',
              'dest': 'input_file_path',
              'required': False})
        ],
        help=': Create a new dynamic account')

    def create(self):
        pargs = self.app.pargs
        valid_dynamic_provider_name, dynamic_provider_name = try_get_value_from_pargs(pargs, 'dynamic_provider_name')
        valid_account_definition, dynamic_account_definition = try_get_value_from_pargs(pargs, 'dynamic_account_definition')

        if not valid_dynamic_provider_name:
            log_invalid_error_message(self.log, 'Dynamic Provider Name')
            return

        if not valid_account_definition:
            log_invalid_error_message(self.log, 'Dynamic Account Definition')
            return
        dynamic_account_input_path = None

        # not required but still need to ensure if it is provided it is valid
        if getattr(pargs, 'input_file_path'):
            valid_file_path, dynamic_account_input_path = try_get_value_from_pargs(pargs, 'input_file_path')
            if not valid_file_path:
                log_invalid_error_message(self.log, 'Dynamic Account Input File')
                return
            if not file_exists(dynamic_account_input_path):
                log_invalid_error_message(self.log, 'Dynamic Account Input File', 'file not found')
                return
            
        response = create_dynamic_account(self, dynamic_provider_name, dynamic_account_definition,
                                          dynamic_account_input_path)
        if not response:
            return
        self.log.info('Dynamic Account Created.')
        pprint_json(response.json())


    @ex(
        arguments=[
            (['-p', '--provider-name'],
             {'help': ': Name of the dynamic provider',
              'dest': 'dynamic_provider_name',
              'required': True}),
            (['-a', '--account-definition'],
             {'help': ': Name of the target dynamic account definition.',
              'dest': 'dynamic_account_definition',
              'required': True}),
            (['-n', '--account-name'],
             {'help': ': Name of the target dynamic account.  If not provided, all accounts for the specified account definition are listed. ',
              'dest': 'dynamic_account_name',
              'required': False}),
            (['-v', '--verbose'],
             {'help': ''': Verbose output. Use the -v flag to get a full listing of dynamic account 
                         attributes. Otherwise, a slim view of each dynamic account definition is returned.''',
              'action': 'store_true'}),
            (['-ps', '--page-size'],
             {'help': ''': Specifies the maximum number of elements to return in the dynamic account listing. 
                         Value must be between 1 and 100. Note, all dynamic/provider/account-definition/account membership 
                         listings will also be limited to this page size.''',
              'dest': 'page_size',
              'required': False}),
            (['-pn', '--page_number'],
             {'help': ''': Specifies the page number (1-based) of results to return.''',
              'dest': 'page_number',
              'required': False}),
            (['-sb', '--sort-by'],
             {'help': ''': Specifies the sort order for the dynamic account listing. This is defined
                         as a single field or comma delimeted list of fields with the sort order
                         (one of:ace|desc) specified in brackets after each and mentioned in single
                         quotes. For example: 'Name(desc)' OR 'Name(desc)','Url(asc)'.''',
              'dest': 'sort_by',
              'required': False})
            ],
        help=''': Return list of dynamic accounts for given account definition or the details of the specified
                dynamic account ''')

    def get(self):
        pargs = self.app.pargs
        valid_dynamic_provider_name, dynamic_provider_name = try_get_value_from_pargs(pargs, 'dynamic_provider_name')
        valid_dynamic_account_definition, dynamic_account_definition = try_get_value_from_pargs(pargs, 'dynamic_account_definition')
        has_dynamic_account_value, dynamic_account_name = try_has_value_from_pargs(pargs, 'dynamic_account_name')
        valid_dynamic_provider_name = not is_null_or_whitespace(dynamic_provider_name)
        valid_account_definition = not is_null_or_whitespace(dynamic_account_definition)
        if is_null_or_whitespace(dynamic_provider_name) and is_null_or_whitespace(dynamic_account_definition):
            self.log.error('Must provide -p and -a arguments.')
            return
        valid_dynamic_provider_name = not is_null_or_whitespace(dynamic_provider_name)
        if not valid_dynamic_provider_name:
            log_invalid_error_message(self.log, 'Dynamic Provider Name')
            return
        dynamic_provider_uri = self.config.dynamic_url + '/' + dynamic_provider_name
        valid_dynamic_account_definition = not is_null_or_whitespace(dynamic_account_definition)
        if not valid_dynamic_account_definition:
            log_invalid_error_message(self.log, 'Dynamic Account Definition')
            return

        if not has_dynamic_account_value:
            uri = dynamic_provider_uri + '/' + dynamic_account_definition
            is_valid, model_data = try_get_filter_model_from_pargs(pargs, True, 2)
            if not is_valid:
                log_invalid_error_message(self.log, model_data)
                return
        else:
            is_valid, dynamic_account_name = try_get_value_from_pargs(pargs, 'dynamic_account_name')
            is_valid = not is_null_or_whitespace(dynamic_account_name)
            if not is_valid:
                log_invalid_error_message(self.log, 'Dynamic Account Name')
                return
            uri = self.config.dynamic_url + '/' + dynamic_provider_name + '/' + dynamic_account_definition + '/' + dynamic_account_name
            is_valid, model_data = try_get_filter_model_from_pargs(pargs, True, 1)
            if not is_valid:
                log_invalid_error_message(self.log, model_data)
                return
        response = issue_request_refresh(self,
            request_method=requests.get,
            params=get_request_kwargs(
                kwargs={'url': uri, 'params': model_data},
                config=self.config,
            )
        )
        if not response or response.status_code != HTTPStatus.OK:
            return
        pprint_json(response.json())


    @ex(
        arguments=[
            (['-p', '--provider-name'],
             {'help': ': Name of the dynamic provider',
              'dest': 'dynamic_provider_name',
              'required': True}),
            (['-a', '--account-definition'],
             {'help': ': Name of the target dynamic account definition.',
              'dest': 'dynamic_account_definition',
              'required': True}),
            (['-n', '--account-name'],
             {'help': ': Name of the target dynamic account.',
              'dest': 'dynamic_account_name',
              'required': True}),
            (['-rm', '--purge-local-resources'],
             {'help': ''': Set to specify that account data should be removed
               from DSS even if the deletion cannot be synchronized with the 
               remote provider.''',
              'action': 'store_true'})
            ],
        help=''': Delete dynamic account under a specific dynamic account definition for a specific dynamic provider''')

    def delete(self):
        pargs = self.app.pargs
        valid_dynamic_provider_name, dynamic_provider_name = try_get_value_from_pargs(pargs, 'dynamic_provider_name')
        valid_account_definition, dynamic_account_definition = try_get_value_from_pargs(pargs, 'dynamic_account_definition')
        valid_account_name, dynamic_account_name = try_get_value_from_pargs(pargs, 'dynamic_account_name')
        if is_null_or_whitespace(dynamic_provider_name) and is_null_or_whitespace(dynamic_account_definition) and is_null_or_whitespace(dynamic_account_name):
            self.log.error('Must provide -p, -a and -n arguments')
            return
        valid_dynamic_provider_name = not is_null_or_whitespace(dynamic_provider_name)
        if not valid_dynamic_provider_name:
            log_invalid_error_message(self.log, 'Dynamic Provider Name')
            return
        dynamic_provider_uri = self.config.dynamic_url + '/' + dynamic_provider_name
        valid_account_definition = not is_null_or_whitespace(dynamic_account_definition)
        if not valid_account_definition:
            log_invalid_error_message(self.log, 'Dynamic Account Definition')
            return
        dynamic_account_definition_uri = dynamic_provider_uri + '/' + dynamic_account_definition
        valid_account_name = not is_null_or_whitespace(dynamic_account_name)
        if not valid_account_name:
            log_invalid_error_message(self.log, 'Dynamic Account Name')
            return

        query_args = {}
        purge_local_resources = self.app.pargs.purge_local_resources
        if purge_local_resources:
            query_args['purge_local_resources'] = purge_local_resources
        
        uri = self.config.dynamic_url + '/' + dynamic_provider_name + '/' + dynamic_account_definition + '/' + dynamic_account_name
        response = issue_request_refresh(self,
            request_method=requests.delete,
            params=get_request_kwargs(
                kwargs={'url': uri,
                        'params': query_args},
                config=self.config,
            )
        )
        if not response or response.status_code != HTTPStatus.OK:
            return
# endregion