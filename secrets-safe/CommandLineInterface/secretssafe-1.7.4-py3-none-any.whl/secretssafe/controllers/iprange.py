import json
from http import HTTPStatus
import requests
from cement import ex
from secretssafe.controllers.base import SecretsSafeBaseController
from secretssafe.utils.cli_utils import *
from secretssafe.utils.validation_utils import *

DESC = 'Manage IP ranges.'


class IpRangeController(SecretsSafeBaseController):

    class Meta:
        label = 'ip-range'
        stacked_on = 'base'
        stacked_type = 'nested'
        description = DESC
        help = ': ' + DESC

    @ex(hide=True)
    def _default(self):
        super()._display_help('ip-range')

    @ex(
        arguments=[
            (['-s', '--safelist-name'],
             {'help': ': Name of the safelist that this IP range will be added to.',
              'dest': 'safelist_name',
              'required': True}),
            (['-f', '--file-path'],
             {'help': ': Path to the file containing IP range data.',
              'dest': 'file_path',
              'required': True})
            ],
        help=': Create an IP range.')
    def create(self):
        pargs = self.app.pargs
        is_valid, safelist_name = try_get_value_from_pargs(pargs, 'safelist_name')
        if not is_valid:
            log_invalid_error_message(self.log, 'Safelist name')
            return
        is_valid, file_path = try_get_value_from_pargs(self.app.pargs, 'file_path')
        if not is_valid:
            log_invalid_error_message(self.log, 'IP Range file')
            return
        data = read_file_contents(file_path)
        url = self.config.safelist_url + '/' + safelist_name + '/ip_range'
        response = issue_request_refresh(self,
            request_method=requests.post,
            params=get_request_kwargs(
                kwargs={'url': url, 'data': data},
                config=self.config,
                headers={'content-type': 'application/json'}
                )
            )
        if not response:
            return
        if response.status_code == HTTPStatus.CREATED:
            print(json.dumps(response.json(), indent=4, sort_keys=True))

    @ex(
        arguments=[
            (['-n', '--name'],
             {'help': ''': If a name is specified, only that IP range is returned and sorting and 
                         pagination options are ignored. If no name is specified, a list of IP 
                         ranges is returned with sorting and pagination options (if specified) 
                         applied.''',
              'dest': 'name',
              'required': False}),
            (['-s', '--safelist-name'],
             {'help': ': Name of the safelist that these IP ranges are associated with.',
              'dest': 'safelist_name',
              'required': True}),
            (['-v', '--verbose'],
             {'help': ''': Verbose output. Use the -v flag to get a full listing of IP range
                         attributes. Otherwise, a slim view of the ip range is returned.''',
              'action': 'store_true'}),
            (['-ps', '--page-size'],
             {'help': ''': Specifies the maximum number of elements to return in the IP range 
                         listing. Value must be between 1 and 100.''',
              'dest': 'page_size',
              'required': False}),
            (['-pn', '--page_number'],
             {'help': ''': Specifies the page number (1-based) of results to return.''',
              'dest': 'page_number',
              'required': False}),
            (['-sb', '--sort-by'],
             {'help': ''': Specifies the sort order for the IP Range listing. This is defined
                         as a single field or comma delimeted list of fields with the sort order
                         (one of:ace|desc) specified in brackets after each and mentioned in single
                         quotes. For example: 'Name(desc)' OR 'Name(desc)','Url(asc)'.''',
              'dest': 'sort_by',
              'required': False})
            ],
        help=': List Secrets Safe SafeLists.')
    def get(self):
        pargs = self.app.pargs
        is_valid, model_data = try_get_filter_model_from_pargs(pargs)
        if not is_valid:
            self.log.error(model_data)
            return
        is_valid, safelist_name = try_get_value_from_pargs(pargs, 'safelist_name')
        if not is_valid:
            log_invalid_error_message(self.log, 'Safelist name')
            return
        has_value, ip_name = try_has_value_from_pargs(pargs, 'name')
        if not has_value:
            url = self.config.safelist_url + '/' + safelist_name + '/ip_range'
        else:
            is_valid = not is_null_or_whitespace(ip_name)
            if not is_valid:
                log_invalid_error_message(self.log, 'IP Range name')
                return
            url = self.config.safelist_url + '/' + safelist_name + '/ip_range' + '/' + ip_name
        request_kwargs = {
            'url': url,
            'params': model_data
        }
        response = issue_request_refresh(self,
            request_method=requests.get,
            params=get_request_kwargs(request_kwargs, self.config)
        )
        if not response:
            return
        if response.status_code == HTTPStatus.OK:
            print(json.dumps(response.json(), indent=4, sort_keys=True))

    @ex(
        arguments=[
            (['-n', '--name'],
             {'help': ': Name of the IP range to be updated.',
              'dest': 'name',
              'required': True}),
            (['-s', '--safelist-name'],
             {'help': ': Name of the safelist that this IP range is associated with.',
              'dest': 'safelist_name',
              'required': True}),
            (['-f', '--file-path'],
             {'help': ': Path to the file containing IP range data.',
              'dest': 'file_path',
              'required': True})
            ],
        help=': Update an IP range.')
    def update(self):
        pargs = self.app.pargs
        is_valid, safelist_name = try_get_value_from_pargs(pargs, 'safelist_name')
        if not is_valid:
            log_invalid_error_message(self.log, 'Safelist name')
            return
        is_valid, name = try_get_value_from_pargs(pargs, 'name')
        if not is_valid:
            log_invalid_error_message(self.log, 'IP Range name')
            return
        is_valid, file_path = try_get_value_from_pargs(self.app.pargs, 'file_path')
        if file_path:
            data = read_file_contents(file_path)
        if not is_valid:
            log_invalid_error_message(self.log, 'IP Range file')
            return
        url = self.config.safelist_url + '/' + safelist_name + '/ip_range/' + name
        response = issue_request_refresh(self,
            request_method=requests.put,
            params=get_request_kwargs(
                kwargs={'url': url, 'data': data},
                config=self.config,
                headers={'content-type': 'application/json'}
                )
            )
        if not response:
            return
        if response.status_code == HTTPStatus.OK:
            print(json.dumps(response.json(), indent=4, sort_keys=True))


    @ex(
        arguments=[
            (['-n', '--name'],
             {'help': ': Name of the IP range to be updated.',
              'dest': 'name',
              'required': True}),
            (['-s', '--safelist-name'],
             {'help': ': Name of the safelist that this IP range is associated with.',
              'dest': 'safelist_name',
              'required': True})
            ],
        help=': Delete an IP range.')
    def delete(self):
        pargs = self.app.pargs
        is_valid, safelist_name = try_get_value_from_pargs(pargs, 'safelist_name')
        if not is_valid:
            log_invalid_error_message(self.log, 'Safelist name')
            return
        is_valid, name = try_get_value_from_pargs(pargs, 'name')
        if not is_valid:
            log_invalid_error_message(self.log, 'IP Range name')
            return
        url = self.config.safelist_url + '/' + safelist_name + '/ip_range/' + name
        response = issue_request_refresh(self,
            request_method=requests.delete,
            params=get_request_kwargs(
                kwargs={'url': url},
                config=self.config
            )
        )
        if not response:
            return
        print_raw_response(response)
        self.log.info('IP range ' + name + ' has been deleted')
