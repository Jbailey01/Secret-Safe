K8_IDENTITY_PROVIDER_NAME = 'kubernetes'

K8_IDENTITY_PROVIDER_CONFIG = '''
{
      "Name": "Kubernetes",
      "Type": "Kubernetes",
      "Enabled": true
}
'''
