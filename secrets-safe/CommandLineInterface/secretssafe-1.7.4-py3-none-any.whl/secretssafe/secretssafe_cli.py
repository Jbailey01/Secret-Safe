import sys
import os
from io import BytesIO
import argcomplete
from cement import App
from cement.core.exc import CaughtSignal
from secretssafe.utils.cli_utils import excepthook
from secretssafe.config import SecretsSafeConfiguration, SIGNALS, LINUX
from secretssafe.controllers.system import SystemController
from secretssafe.controllers.user import UserController
from secretssafe.controllers.license import LicenseController
from secretssafe.controllers.group import GroupController
from secretssafe.controllers.identity import IdentityController
from secretssafe.controllers.application import ApplicationController
from secretssafe.controllers.scope import ScopeController
from secretssafe.controllers.secret import SecretController
from secretssafe.controllers.metadata import MetadataController
from secretssafe.controllers.authorization import AuthorizationController
from secretssafe.controllers.safelist import SafelistController
from secretssafe.controllers.iprange import IpRangeController
from secretssafe.controllers.eventsink import EventSinkController
from secretssafe.controllers.generator import GeneratorController
from secretssafe.controllers.context import ContextController
from secretssafe.controllers.completion import CompletionController
from secretssafe.utils.argparse_overrides import ArgparseArgumentHandlerOverride
from secretssafe.controllers.mfa import MfaController
from secretssafe.controllers.setting import SettingController
from secretssafe.controllers.dynamic import DynamicController
from secretssafe.controllers.dynamic import Provider
from secretssafe.controllers.dynamic import AccountDefinition
from secretssafe.controllers.dynamic import Account

class SecretsSafeCli(App):

    def __init__(self, config, *args, **kwargs):
        self.ss_config = config
        super().__init__(
            *args,
            **{**kwargs, 'config_defaults': config.defaults}
            )

    class Meta:
        label = 'ssrun'
        base_controller = 'base'
        debug_argument_options = None
        argument_handler = ArgparseArgumentHandlerOverride
        hooks = [('pre_argument_parsing', lambda app: argcomplete.autocomplete(app.args))]
        handlers = [
            UserController,
            SecretController,
            ScopeController,
            SafelistController,
            MetadataController,
            EventSinkController,
            GeneratorController,
            LicenseController,
            IpRangeController,
            IdentityController,
            GroupController,
            ContextController,
            AuthorizationController,
            ApplicationController,
            SystemController,
            CompletionController,
            MfaController,
            SettingController,
            DynamicController,
            Provider,
            AccountDefinition,
            Account
            ]


def execute_cli():
    sys.excepthook = excepthook
    config = SecretsSafeConfiguration()
    _read_io(config)
    with SecretsSafeCli(config=config) as app:
        try:
            app.run()
        except CaughtSignal as exception:
            if exception.signum in SIGNALS:
                pass


def _read_io(config):
    if not sys.stdin.isatty():
        # this is not interactive, read from stdin
        subcommands = None
        if len(sys.argv) > 1:
            subcommands = sys.argv[1:]
            sys.argv = sys.argv[:1]
        config.stdin_file = BytesIO(sys.stdin.buffer.read())
        if subcommands:
            sys.argv.extend(subcommands)
        # redirect to tty stream
        sys.stdin = open('/dev/tty' if os.name == LINUX else 'CON:')
    elif '--v' in sys.argv:
        # interpret --v flag to set log level to INFO
        config.defaults['log.logging']['level'] = 'INFO'
        sys.argv.remove('--v')
