import os
import logging
from io import StringIO
from contextlib import redirect_stdout, redirect_stderr
from collections import namedtuple
from secretssafe.utils.cli_utils import (authenticate_application as auth_application,
                                         authenticate_user as auth_user, file_exists)
from secretssafe.utils.secret_scope_utils import (get_secret, create_secret_with_bytes, 
                                                  create_secret_with_generator, create_secret_with_file)
from secretssafe.utils.dynamic_utils import create_dynamic_account, create_dyanmic_account_with_bytes
from secretssafe.config import (SecretsSafeConfiguration, SECRETSSAFE_HOST, SECRETSSAFE_PORT,
                                SECRETSSAFE_VERIFY_CA)

CommandOutput = namedtuple('CommandOutput', ['command_return', 'stdout', 'stderr'])
class SecretsSafeClient:

    def __init__(self, host, port, verify_ca):
        self._configure_client(host, port, verify_ca)
        self.log = logging.getLogger(__name__)

    def authenticate_application(self, api_key, application_name):
        response = auth_application(self.log, self.config, api_key, application_name)
        if response.ok:
            return True, None
        return False, 'Authentication failed with status code {}'.format(response.status_code)

    def authenticate_user(self, username, password, identity_provider_name):
        _, _, response = auth_user(self.log, self.config, username, password, identity_provider_name)
        if response.ok:
            return True, None
        return False, 'Authentication failed with status code {}'.format(response.status_code)

    def execute_func_and_capture_output(self, cli_func, *args):
        stderr_io = StringIO()
        stdout_io = StringIO()
        with redirect_stdout(stdout_io), redirect_stderr(stderr_io):
            command_return = cli_func(*args)
        stdout_val = stdout_io.getvalue()
        stderr_val = stderr_io.getvalue()
        return CommandOutput(command_return, stdout_val, stderr_val)

    def execute_and_validate_response(self, cli_func, *args):
        execution_result = self.execute_func_and_capture_output(cli_func, *args)

        if execution_result.command_return is not None and execution_result.command_return.ok:
            return True
        if execution_result.stderr:
            return execution_result.stderr
        elif execution_result.stdout:
            return execution_result.stdout

    def create_secret(self, uri, secret_bytes):
        return self.execute_and_validate_response(create_secret_with_bytes, self, uri, secret_bytes, False)

    def create_secret_from_file(self, uri, file_path):
        return self.execute_and_validate_response(create_secret_with_file, self, uri, file_path, False)

    def create_secret_using_generator(self, uri, secret_generator):
        return self.execute_and_validate_response(create_secret_with_generator, self, uri, secret_generator, False)

    def retrieve_secret(self, uri):
        secret = get_secret(self, uri)
        return secret

    def create_dynamic_account(self, provider, account_definition, input_file):
        if input_file and not file_exists(input_file):
            return False, 'input file not found - {}'.format(input_file)

        command_output = self.execute_func_and_capture_output(create_dynamic_account, self,
                                                              provider, account_definition, input_file)
        if command_output.command_return and command_output.command_return.ok:
            return True, command_output.command_return.json()
        if command_output.stderr:
            return False, command_output.stderr
        if command_output.stdout:
            return False, command_output.stdout
        return False, None

    def create_dynamic_account_with_json(self, provider, account_definition, json_string):
        json_bytes = json_string.encode()
        command_output = self.execute_func_and_capture_output(create_dyanmic_account_with_bytes, self,
                                                              provider, account_definition, json_bytes)
        if command_output.command_return and command_output.command_return.ok:
            return True, command_output.command_return.json()
        if command_output.stderr:
            return False, command_output.stderr
        if command_output.stdout:
            return False, command_output.stdout
        return False, None

    def _configure_client(self, host, port, verify_ca):
        '''
        Read values from environment if not handed into function, set
        configuration json and notify configuration to do no file io (secret
        retrieval, config json dumping, hard exits, etc.)
        '''
        host_env = os.getenv(SECRETSSAFE_HOST)
        port_env = os.getenv(SECRETSSAFE_PORT)
        verify_ca_env = os.getenv(SECRETSSAFE_VERIFY_CA)

        host = host_env if not host else host
        port = port_env if not port else port
        verify_ca = verify_ca if verify_ca is not None else verify_ca_env

        self.config = SecretsSafeConfiguration(host, port, verify_ca)
        self.config.assign_endpoints()
        self.config.integrated = True
