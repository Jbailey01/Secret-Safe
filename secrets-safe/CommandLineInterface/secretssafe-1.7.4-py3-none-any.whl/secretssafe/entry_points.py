from secretssafe.secretssafe_cli import execute_cli
from secretssafe.secretssafe_client import SecretsSafeClient

__all__ = ['create_client']


def cli():
    '''
    Generic console script entry point
    '''
    execute_cli()


def create_client(host=None, port=None, verify_ca=None):
    '''
    Creates and returns instance of the Secrets Safe client
    '''
    return SecretsSafeClient(host, port, verify_ca)


if __name__ == '__main__':
    cli()
