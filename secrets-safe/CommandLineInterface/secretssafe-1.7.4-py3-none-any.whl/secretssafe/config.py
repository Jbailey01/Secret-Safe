import re
import signal as _signal
import tempfile
import os
import base64
from cement.utils.misc import init_defaults

# environment configurable variable names
SECRETSSAFE_HOST = 'SECRETSSAFE_HOST'
SECRETSSAFE_PORT = 'SECRETSSAFE_PORT'
SECRETSSAFE_VERIFY_CA = 'SECRETSSAFE_VERIFY_CA'
SECRETSSAFE_CA_DATA = 'SECRETSSAFE_CA_DATA'
SECRETSSAFE_API_RESPONSE = 'SECRETSSAFE_API_RESPONSE'
SECRETSSAFE_AUTH_TOKEN = 'SECRETSSAFE_AUTH_TOKEN'
SECRETSSAFE_REFRESH_TOKEN = 'SECRETSSAFE_REFRESH_TOKEN'

OPTIONAL_ENV_VAR_NAMES = [SECRETSSAFE_VERIFY_CA, SECRETSSAFE_AUTH_TOKEN, SECRETSSAFE_REFRESH_TOKEN, SECRETSSAFE_CA_DATA]
REQUIRED_ENV_VAR_NAMES = [SECRETSSAFE_HOST, SECRETSSAFE_PORT]
ALL_ENV_VAR_NAMES = REQUIRED_ENV_VAR_NAMES + OPTIONAL_ENV_VAR_NAMES

# application configurable variable names

LINUX = 'posix'
WINDOWS = 'nt'
UNICODE_ENCODING = 'unicode'
ALL = 'all'
INTERNAL = 'internal'

NESTED_CONTROLLER_CMDS = {
    'application', 'authorization', 'dynamic', 'event-sink', 'group', 'identity', 'init', 'ip-range',
    'license', 'login', 'logout', 'metadata', 'safelist', 'scope', 'seal', 'secret', 'status',
    'unseal', 'user', 'whoami', 'context', 'completion', 'mfa', 'setting'
    }

SUBCMDS = {'create', 'get', 'update', 'delete', 'regenerate_api_key', 'operations', 'generate', 'provider',
    'account-definition'}

ALL_CMDS = NESTED_CONTROLLER_CMDS | SUBCMDS

NO_CONFIG_ARGS = {'-h', '--help', '--version', 'context', 'completion'}
NO_AUTH_CMDS = {'init', 'logout', 'login', 'unseal', 'context', 'completion'}

SIGNALS = [_signal.SIGTERM, _signal.SIGINT, _signal.SIGABRT]
FILE_ATTRIBUTE_HIDDEN = 0x02

# principal name validation
PRINCIPAL_NAME_REGEX = re.compile(r"^[a-zA-Z0-9:@:$_.+!*'()-]+$")
MAX_NAME_LENGTH = 100
MIN_NAME_LENGTH = 3

INVALID_SUFFIX = ' is invalid'

MAX_PASSWORD_CONFIRM_ATTEMPTS = 1

DEFAULT_API_VERSION = 'v1'

CONTEXT_HEADERS = ['CURRENT', 'NAME', 'HOSTNAME/IP', 'PORT', 'API VERSION', 'SSL CA']
TABLE_FORMAT = 'plain'

STATUS_HEADERS = ['ServiceType', 'ServiceInstance', 'Version', 'Timestamp', 'State', 'IsUnsealed']
OUTPUT_JSON = 'json'
OUTPUT_TABLE = 'table'

# pylint: disable=too-many-instance-attributes
class SecretsSafeConfiguration:

    # API endpoints defined at runtime
    api_root_url = None
    authentication_url = None
    application_authentication_url = None
    initialization_url = None
    unseal_url = None
    seal_url = None
    license_url = None
    secret_root_url = None
    authorization_url = None
    status_url = None
    resource_type_url = None
    group_url = None
    safelist_url = None
    principal_url = None
    internal_user_url = None
    internal_application_url = None
    event_sink_url = None
    secret_url = None
    generator_url = None
    mfa_url = None
    setting_url = None
    dynamic_url = None

    # reference to the list of all contexts as configured in `secretssafe_contexts.json`
    contexts = []

    # refererence to the current context as configured in `secretssafe_contexts.json`
    current_context = {}

    # reference to data captured by standard in
    stdin_file = None

    # removes all file io for integrated environments, ie ansible. forces configuration to be read
    # through environment variables or entry point arguments and not cached to disc
    integrated = False

    # default log only errors
    defaults = init_defaults('log.logging')
    defaults['log.logging']['level'] = 'ERROR'

    def __init__(self, host=None, port=None, verify_ca=None):
        if host:
            self.current_context[SECRETSSAFE_HOST] = host
        if port:
            self.current_context[SECRETSSAFE_PORT] = port
        if verify_ca is not None:
            self.current_context[SECRETSSAFE_VERIFY_CA] = verify_ca

    def assign_endpoints(self):
        if not self.current_context:
            return
        hostname = self.current_context.get(SECRETSSAFE_HOST, 'localhost')
        port = self.current_context.get(SECRETSSAFE_PORT, 8443)
        api_version = self.current_context.get('api_version', DEFAULT_API_VERSION)
        root_url = 'https://' + hostname + ':' + str(port)
        self.api_root_url = root_url + '/secretssafe/api/' + api_version
        self.authentication_url = self.api_root_url + '/connect/token'
        self.application_authentication_url = self.api_root_url + '/connect/api_key_token'
        self.authentication_refresh_url = self.api_root_url + '/connect/tokenrefresh'
        self.initialization_url = self.api_root_url + '/system/initialize'
        self.unseal_url = self.api_root_url + '/system/unseal'
        self.seal_url = self.api_root_url + '/system/seal'
        self.license_url = self.api_root_url + '/system/license'
        self.authorization_url = self.api_root_url + '/authorize'
        self.status_url = self.api_root_url + '/status'
        self.resource_type_url = self.api_root_url + '/resource_type'
        self.safelist_url = self.api_root_url + '/safelist'
        self.secret_url = self.api_root_url + '/secret'
        self.principal_url = self.api_root_url + '/principal'
        self.generator_url = self.api_root_url + '/generator'
        self.event_sink_url = self.api_root_url + '/system/event_sink'
        self.internal_user_url = self.principal_url + '/internal/user'
        self.internal_application_url = self.principal_url + '/internal/application'
        self.group_url = self.principal_url + '/internal/group'
        self.mfa_url = self.api_root_url + '/system/multi_factor'
        self.setting_url = self.api_root_url + '/system/settings'
        self.dynamic_url = self.api_root_url + '/dynamic'

    def get_auth_token(self):
        auth_token = os.getenv('SECRETSSAFE_AUTH_TOKEN')
        if auth_token is not None:
            return auth_token
        return self.current_context.get(SECRETSSAFE_AUTH_TOKEN, '')

    def get_refresh_token(self):
        return self.current_context.get(SECRETSSAFE_REFRESH_TOKEN, '')

    def get_verify_ca(self):
        return VerifyCaContext(self.current_context)

class VerifyCaContext:
    """
    Simple context manager for writing ca data to a temp file and cleaning up on exit
    """
    temp_cert_path = None
    verify_ca = True
    
    def __init__(self, ssrun_context):

        verify_ca = ssrun_context.get(SECRETSSAFE_VERIFY_CA)
        # cert verification has been explicitly turned off
        if str(verify_ca).lower() == 'false':
            self.verify_ca = False
            return
        ca_data = ssrun_context.get(SECRETSSAFE_CA_DATA)
        # ca bundle is inline
        if ca_data:
            ca_data_bytes = base64.b64decode(ca_data)
            cert = tempfile.NamedTemporaryFile(delete=False)
            cert.write(ca_data_bytes)
            self.temp_cert_path = cert.name
            self.verify_ca = cert.name
            cert.close()
            return
        # return either True or file path to ca
        self.verify_ca = {'true': True}.get(str(verify_ca).lower(), verify_ca)

    def __enter__(self):
        return self.verify_ca

    def __exit__(self, type, value, traceback):
        if self.temp_cert_path:
            try:
                os.unlink(self.temp_cert_path)
            except OSError:
                pass
